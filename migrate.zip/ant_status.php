<?php
include ("connect.php");
include ("function.php");

head_ant();
nav_ant();
?>

<font face="Arial"><h1>Antragsdatenbank</h1>

<?php

$antgesamt=0;
$antvorb=0;
$anteing=0;
$antalk=0;
$antalb=0;
$antriss=0;
$antrech=0;
$antarchiv=0;
$antstorno=0;
$antaway=0;

$query="SELECT * from antrag;";
$result=mysql_db_query($dbname,$query);
while($r=mysql_fetch_array($result))
  {
   $antgesamt++;
   if ($r[aktort_id]=='1') $antvorb++;
   if ($r[aktort_id]=='2') $antbuero++;
   if ($r[aktort_id]=='3') $anteing++;
   if ($r[aktort_id]=='4') $antalk++;
   if ($r[aktort_id]=='5') $antalb++;
   if ($r[aktort_id]=='11') $antriss++;
   if ($r[aktort_id]=='6') $antrech++;
   if ($r[aktort_id]=='7') $antarchiv++;
   if ($r[aktort_id]=='8') $antstorno++;
   if ($r[aktort_id]=='9') $antback++;
   if ($r[aktort_id]=='99') $antaway++;
  }


echo "<table>
<tr>
<td colspan=\"2\">Analyse nach Aktenort</td>
</tr>
<tr><td colspan=\"2\"><hr></td></tr>
<tr>
<td width=\"300\">Vorbereitung:</td>
<td align=\"right\">$antvorb</td>
</tr>
<tr>
<td>beim Vermessungsb&uuml;ro</td>
<td align=\"right\">$antbuero</td>
</tr>
<tr>
<td>Eingangspr&uuml;fung</td>
<td align=\"right\">$anteing</td>
</tr>
<tr>
<td>&Uuml;bernahme in die ALK</td>
<td align=\"right\">$antalk</td>
</tr>
<tr>
<td>&Uuml;bernahme/ALB</td>
<td align=\"right\">$antalb</td>
</tr>
<tr>
<td>Risse scannen</td>
<td align=\"right\">$antriss</td>
</tr>
<tr>
<td>Rechnung schreiben</td>
<td align=\"right\">$antrech</td>
</tr>
<tr>
<td>im Archiv</td>
<td align=\"right\">$antarchiv</td>
</tr>
<tr><td colspan=\"2\"><hr></td></tr>
<tr>
<td>storniert</td>
<td align=\"right\">$antstorno</td>
</tr>
<tr>
<td>zur&uuml;ck an Vermessungsstelle</td>
<td align=\"right\">$antback</td>
</tr>
<tr>
<td>???</td>
<td align=\"right\">$antaway</td>
</tr>
</table><br><br></font>";


nav_ant();
bottom();
?>