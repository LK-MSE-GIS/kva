<?php
include ("connect.php");
include ("li_function.php");


?>
<a href="li_a.php"><h3>A-Liste</h3></a>
<br>
<a href="li_b.php"><h3>B-Liste</h3></a>
<br>
<a href="li_balk.php"><h3>B-Liste (ALK-ALB Abgleich)</h3></a>
<br>
<a href="li_c.php"><h3>C-Liste</h3></a>
<br>
<?php
bottom();
?>