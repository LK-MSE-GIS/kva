<?php
include ("connect.php");
include ("function.php");

head_flur();
nav_flur("alkgrund");

$fgesamt=0;
$query="SELECT * from flur;";
$result=mysql_db_query($dbname,$query);
while($r=mysql_fetch_array($result))
  {
   $fgesamt++;
   }

echo "<table>
<tr>
<td style=\"font-family:Arial; font-size: 24pt; font-weight: bold\">Statistik der Flurdatenbank (",$fgesamt," Fluren)</td>
</tr>
<tr>
<td style=\"font-family:Arial; font-size: 12pt; font-weight: normal\">Datum: $print_datum</td>
</tr>
</table>";

$fselekt=20;
$c20=0;
$sel_query="SELECT * from selekt WHERE sel_id=$fselekt";
$sel_result=mysql_db_query($dbname,$sel_query);
$sel_r=mysql_fetch_array($sel_result);
$query=$sel_r[query];
$result=mysql_db_query($dbname,$query);
while($r=mysql_fetch_array($result))
  {
   $c20++;
   }

$fselekt=21;
$c21=0;
$c22=0;
$sel_query="SELECT * from selekt WHERE sel_id=$fselekt";
$sel_result=mysql_db_query($dbname,$sel_query);
$sel_r=mysql_fetch_array($sel_result);
$query=$sel_r[query];
$result=mysql_db_query($dbname,$query);
while($r=mysql_fetch_array($result))
  {
    $bovquery="SELECT * FROM bov WHERE bov_id=$r[bov]";
    $bovresult=mysql_db_query($dbname,$bovquery);
    $bovr=mysql_fetch_array($bovresult);
    if ($bovr[busy]=='1') $c21++;
    if ($bovr[busy]=='0') $c22++;
   }

$fselekt=10;
$c10=0;
$sel_query="SELECT * from selekt WHERE sel_id=$fselekt";
$sel_result=mysql_db_query($dbname,$sel_query);
$sel_r=mysql_fetch_array($sel_result);
$query=$sel_r[query];
$result=mysql_db_query($dbname,$query);
while($r=mysql_fetch_array($result))
  {
    $bovquery="SELECT * FROM bov WHERE bov_id=$r[bov]";
    $bovresult=mysql_db_query($dbname,$bovquery);
    $bovr=mysql_fetch_array($bovresult);
    if ($bovr[busy]=='1') $c10++;
   }



$fselekt=60;
$c60=0;
$sel_query="SELECT * from selekt WHERE sel_id=$fselekt";
$sel_result=mysql_db_query($dbname,$sel_query);
$sel_r=mysql_fetch_array($sel_result);
$query=$sel_r[query];
$result=mysql_db_query($dbname,$query);
while($r=mysql_fetch_array($result))
  {
   $c60++;
   }

$fselekt=61;
$c61=0;
$sel_query="SELECT * from selekt WHERE sel_id=$fselekt";
$sel_result=mysql_db_query($dbname,$sel_query);
$sel_r=mysql_fetch_array($sel_result);
$query=$sel_r[query];
$result=mysql_db_query($dbname,$query);
while($r=mysql_fetch_array($result))
  {
   $c61++;
   }

$fselekt=0;
$c0=0;
$sel_query="SELECT * from selekt WHERE sel_id=$fselekt";
$sel_result=mysql_db_query($dbname,$sel_query);
$sel_r=mysql_fetch_array($sel_result);
$query=$sel_r[query];
$result=mysql_db_query($dbname,$query);
while($r=mysql_fetch_array($result))
  {
   $c0++;
   }

$fselekt=1;
$c1=0;
$sel_query="SELECT * from selekt WHERE sel_id=$fselekt";
$sel_result=mysql_db_query($dbname,$sel_query);
$sel_r=mysql_fetch_array($sel_result);
$query=$sel_r[query];
$result=mysql_db_query($dbname,$query);
while($r=mysql_fetch_array($result))
  {
   $c1++;
   }

$fselekt=3;
$c3=0;
$sel_query="SELECT * from selekt WHERE sel_id=$fselekt";
$sel_result=mysql_db_query($dbname,$sel_query);
$sel_r=mysql_fetch_array($sel_result);
$query=$sel_r[query];
$result=mysql_db_query($dbname,$query);
while($r=mysql_fetch_array($result))
  {
   $c3++;
   }

$fselekt=4;
$c4=0;
$sel_query="SELECT * from selekt WHERE sel_id=$fselekt";
$sel_result=mysql_db_query($dbname,$sel_query);
$sel_r=mysql_fetch_array($sel_result);
$query=$sel_r[query];
$result=mysql_db_query($dbname,$query);
while($r=mysql_fetch_array($result))
  {
   $c4++;
   }


$fselekt=5;
$c5=0;
$sel_query="SELECT * from selekt WHERE sel_id=$fselekt";
$sel_result=mysql_db_query($dbname,$sel_query);
$sel_r=mysql_fetch_array($sel_result);
$query=$sel_r[query];
$result=mysql_db_query($dbname,$query);
while($r=mysql_fetch_array($result))
  {
   $c5++;
   }

$fselekt=9;
$c9=0;
$sel_query="SELECT * from selekt WHERE sel_id=$fselekt";
$sel_result=mysql_db_query($dbname,$sel_query);
$sel_r=mysql_fetch_array($sel_result);
$query=$sel_r[query];
$result=mysql_db_query($dbname,$query);
while($r=mysql_fetch_array($result))
  {
   $c9++;
   }

echo "<table style=\"font-family:Arial; font-size: 12pt; font-weight: normal\">
<tr>
<td valign=\"top\"><table style=\"font-family:Arial; font-size: 12pt; font-weight: normal\">
<tr>
<td colspan=\"2\"><b>Bodenordnungsverfahren</b></td></tr>
<tr><td><small><a href=\"flur_selekt2.php?fselekt=20\">BOV-Fluren gesamt:</a></small></td>
<td align=\"right\">$c20</td>
</tr>
<tr><td><small><a href=\"flur_selekt2.php?fselekt=21\">Fluren in laufenden<br>Verfahren:</a></small></td>
<td align=\"right\">$c21</td>
</tr>
<tr><td><small><a href=\"flur_selekt2.php?fselekt=22\">Fluren aus abgeschlossenen<br>Verfahren:</a></small></td>
<td align=\"right\">$c22</td>
</tr>
<tr>
<td colspan=\"2\"><hr></td></tr>
<td colspan=\"2\"><b>Siedlungsmessungen</b></td></tr>
<tr><td><small><a href=\"flur_selekt2.php?fselekt=60\">Fluren in Siedlungs-<br>messungen gesamt:</a></small></td>
<td align=\"right\">$c60</td>
</tr>
<tr><td><small><a href=\"flur_selekt2.php?fselekt=61\">durch Werkvertrag<br>berechnet:</a></small></td>
<td align=\"right\">$c61</td>
</tr>
<tr>
<td colspan=\"2\"><hr></td></tr>
<td colspan=\"2\"><b>&Uuml;berarbeitung von<br>Stra&szlig;en/Hausnummern</b></td></tr>
<tr><td><small>Fluren mit Geb&auml;udebestand:</small></td>
<td align=\"right\">";
$gebflur=$fgesamt-$c9;
echo $gebflur,"</td>
</tr>
<tr><td><small><a href=\"flur_selekt2.php?fselekt=0\">keine Aktion:</a></small></td>
<td align=\"right\">$c0</td>
</tr>
<tr><td><small><a href=\"flur_selekt2.php?fselekt=10\">werden durch BOV erledigt</a></small></td>
<td align=\"right\">$c10</td>
</tr>
<tr><td><small><a href=\"flur_selekt2.php?fselekt=1\">Karten beim Amt:</a></small></td>
<td align=\"right\">$c1</td>
</tr>
<tr><td><small><a href=\"flur_selekt2.php?fselekt=3\">vom Amt zur&uuml;ck<br>noch nicht in der ALK</a></small></td>
<td align=\"right\">$c3</td>
</tr>
<tr><td><small><a href=\"flur_selekt2.php?fselekt=5\">vom Amt zur&uuml;ck<br>noch nicht im ALB</a></small></td>
<td align=\"right\">$c5</td>
</tr>
<tr><td><small>in ALB und ALK<br>eingearbeitet</small></td>
<td align=\"right\">$c4</td>
</tr>
</table></td>
<td>&nbsp;</td>
<td valign=\"top\">
<table style=\"font-family:Arial; font-size: 12pt; font-weight: normal\">";

$fselekt=33;
$c33=0;
$sel_query="SELECT * from selekt WHERE sel_id=$fselekt";
$sel_result=mysql_db_query($dbname,$sel_query);
$sel_r=mysql_fetch_array($sel_result);
$query=$sel_r[query];
$result=mysql_db_query($dbname,$query);
while($r=mysql_fetch_array($result))
  {
   $c33++;
   }

$fselekt=35;
$c35=0;
$sel_query="SELECT * from selekt WHERE sel_id=$fselekt";
$sel_result=mysql_db_query($dbname,$sel_query);
$sel_r=mysql_fetch_array($sel_result);
$query=$sel_r[query];
$result=mysql_db_query($dbname,$query);
while($r=mysql_fetch_array($result))
  {
   $c35++;
   }

$fselekt=36;
$c36=0;
$sel_query="SELECT * from selekt WHERE sel_id=$fselekt";
$sel_result=mysql_db_query($dbname,$sel_query);
$sel_r=mysql_fetch_array($sel_result);
$query=$sel_r[query];
$result=mysql_db_query($dbname,$query);
while($r=mysql_fetch_array($result))
  {
   $c36++;
   }


$fselekt=37;
$c37=0;
$sel_query="SELECT * from selekt WHERE sel_id=$fselekt";
$sel_result=mysql_db_query($dbname,$sel_query);
$sel_r=mysql_fetch_array($sel_result);
$query=$sel_r[query];
$result=mysql_db_query($dbname,$query);
while($r=mysql_fetch_array($result))
  {
   $c37++;
   }



$fselekt=38;
$c38=0;
$sel_query="SELECT * from selekt WHERE sel_id=$fselekt";
$sel_result=mysql_db_query($dbname,$sel_query);
$sel_r=mysql_fetch_array($sel_result);
$query=$sel_r[query];
$result=mysql_db_query($dbname,$query);
while($r=mysql_fetch_array($result))
  {
   $c38++;
   }

$fselekt=42;
$c42=0;
$sel_query="SELECT * from selekt WHERE sel_id=$fselekt";
$sel_result=mysql_db_query($dbname,$sel_query);
$sel_r=mysql_fetch_array($sel_result);
$query=$sel_r[query];
$result=mysql_db_query($dbname,$query);
while($r=mysql_fetch_array($result))
  {
   $c42++;
   }

$fselekt=43;
$c43=0;
$sel_query="SELECT * from selekt WHERE sel_id=$fselekt";
$sel_result=mysql_db_query($dbname,$sel_query);
$sel_r=mysql_fetch_array($sel_result);
$query=$sel_r[query];
$result=mysql_db_query($dbname,$query);
while($r=mysql_fetch_array($result))
  {
   $c43++;
   }





echo "<tr>
<td colspan=\"2\"><b>Altgeb&auml;udeerfassung</b></td>
</tr>
<tr>
<td valign=\"top\"><small>Fluren mit Geb&auml;udebestand:</small></td>
<td align=\"right\"><b>$gebflur</b></td></tr>
<tr>
<td valign=\"top\"><small><a href=\"flur_selekt2.php?fselekt=33\">noch keine Aktion</a></small></td>
<td align=\"right\"><b>$c33</b></td></tr>
<tr>
<td valign=\"top\"><small><a href=\"flur_selekt2.php?fselekt=38\">durch Werkvertr&auml;ge<br>erledigt</a></small></td>
<td align=\"right\"><b>$c38</b></td></tr>
<tr>
<td valign=\"top\"><small><a href=\"flur_selekt2.php?fselekt=35\">Erfassung abgeschlossen:</a></small></td>
<td align=\"right\"><b>$c35</b></td></tr>
<tr><td colspan=\"2\"><hr></td></tr>
<tr>
<td valign=\"top\"><small><a href=\"flur_selekt2.php?fselekt=37\">Erfassung abgeschlossen<br>noch nicht in der ALK</a></small></td>
<td align=\"right\"><b>$c37</b></td></tr>
<tr>
<td valign=\"top\"><small>bisher in die ALK<br>eingearbeitet</small></td>
<td align=\"right\"><b>$c36</b></td></tr>
<tr><td colspan=\"2\"><hr></td></tr>
<tr>
<td colspan=\"2\"><b>Geb&auml;ude ab 1992</b></td>
</tr>
<tr>
<td valign=\"top\"><small>Fluren mit Geb&auml;udebestand:</small></td>
<td align=\"right\"><b>$gebflur</b></td></tr>
<tr>
<td valign=\"top\"><small>Aufforderungen<br>verschickt</small></td>
<td align=\"right\"><b>$c42</b></td></tr>
<tr>
<td valign=\"top\"><small>Einmessungen abgeschlossen</small></td>
<td align=\"right\"><b>$c43</b></td></tr>
<tr>
<td valign=\"top\"><small>noch offen:</small></td>";
$neugeboffenalk=$gebflur-$c43;
echo "<td align=\"right\"><b>$neugeboffenalk</b></td></tr>";

$fselekt=70;
$c70=0;
$sel_query="SELECT * from selekt WHERE sel_id=$fselekt";
$sel_result=mysql_db_query($dbname,$sel_query);
$sel_r=mysql_fetch_array($sel_result);
$query=$sel_r[query];
$result=mysql_db_query($dbname,$query);
while($r=mysql_fetch_array($result))
  {
   $c70++;
   }

$fselekt=71;
$c71=0;
$sel_query="SELECT * from selekt WHERE sel_id=$fselekt";
$sel_result=mysql_db_query($dbname,$sel_query);
$sel_r=mysql_fetch_array($sel_result);
$query=$sel_r[query];
$result=mysql_db_query($dbname,$query);
while($r=mysql_fetch_array($result))
  {
   $c71++;
   }

$fselekt=74;
$c74=0;
$sel_query="SELECT * from selekt WHERE sel_id=$fselekt";
$sel_result=mysql_db_query($dbname,$sel_query);
$sel_r=mysql_fetch_array($sel_result);
$query=$sel_r[query];
$result=mysql_db_query($dbname,$query);
while($r=mysql_fetch_array($result))
  {
   $c74++;
   }

echo "<tr><td colspan=\"2\"><hr></td></tr>
<tr>
<td colspan=\"2\"><b>Bodensch&auml;tzung</b></td>
</tr>
<tr>
<td valign=\"top\"><small><a href=\"flur_selekt2.php?fselekt=70\">Bodensch&auml;tzung existiert:</a></small></td>
<td align=\"right\"><b>$c70</b></td></tr>
<tr>
<td valign=\"top\"><small><a href=\"flur_selekt2.php?fselekt=71\">in ALK eingearbeitet:</a></small></td>
<td align=\"right\"><b>$c71</b></td></tr>
<tr>
<td valign=\"top\"><small><a href=\"flur_selekt2.php?fselekt=74\">noch offen:</a></small></td>
<td align=\"right\"><b>$c74</b></td></tr>";

echo "</table></td>
<td>&nbsp;</td>
<td valign=\"top\"><table style=\"font-family:Arial; font-size: 12pt; font-weight: normal\">";

$fselekt=51;
$c51=0;
$sel_query="SELECT * from selekt WHERE sel_id=$fselekt";
$sel_result=mysql_db_query($dbname,$sel_query);
$sel_r=mysql_fetch_array($sel_result);
$query=$sel_r[query];
$result=mysql_db_query($dbname,$query);
while($r=mysql_fetch_array($result))
  {
   $c51++;
   }


$fselekt=56;
$c56=0;
$sel_query="SELECT * from selekt WHERE sel_id=$fselekt";
$sel_result=mysql_db_query($dbname,$sel_query);
$sel_r=mysql_fetch_array($sel_result);
$query=$sel_r[query];
$result=mysql_db_query($dbname,$query);
while($r=mysql_fetch_array($result))
  {
   $c56++;
   }

$fselekt=57;
$c57=0;
$sel_query="SELECT * from selekt WHERE sel_id=$fselekt";
$sel_result=mysql_db_query($dbname,$sel_query);
$sel_r=mysql_fetch_array($sel_result);
$query=$sel_r[query];
$result=mysql_db_query($dbname,$query);
while($r=mysql_fetch_array($result))
  {
   $c57++;
   }

$fselekt=58;
$c58=0;
$sel_query="SELECT * from selekt WHERE sel_id=$fselekt";
$sel_result=mysql_db_query($dbname,$sel_query);
$sel_r=mysql_fetch_array($sel_result);
$query=$sel_r[query];
$result=mysql_db_query($dbname,$query);
while($r=mysql_fetch_array($result))
  {
   $c58++;
   }

$fselekt=500;
$c500=0;
$sel_query="SELECT * from selekt WHERE sel_id=$fselekt";
$sel_result=mysql_db_query($dbname,$sel_query);
$sel_r=mysql_fetch_array($sel_result);
$query=$sel_r[query];
$result=mysql_db_query($dbname,$query);
while($r=mysql_fetch_array($result))
  {
   $c500++;
   }

$fselekt=501;
$c501=0;
$sel_query="SELECT * from selekt WHERE sel_id=$fselekt";
$sel_result=mysql_db_query($dbname,$sel_query);
$sel_r=mysql_fetch_array($sel_result);
$query=$sel_r[query];
$result=mysql_db_query($dbname,$query);
while($r=mysql_fetch_array($result))
  {
   $c501++;
   }

$fselekt=503;
$c503=0;
$sel_query="SELECT * from selekt WHERE sel_id=$fselekt";
$sel_result=mysql_db_query($dbname,$sel_query);
$sel_r=mysql_fetch_array($sel_result);
$query=$sel_r[query];
$result=mysql_db_query($dbname,$query);
while($r=mysql_fetch_array($result))
  {
   $c503++;
   }

$fselekt=502;
$c502=0;
$sel_query="SELECT * from selekt WHERE sel_id=$fselekt";
$sel_result=mysql_db_query($dbname,$sel_query);
$sel_r=mysql_fetch_array($sel_result);
$query=$sel_r[query];
$result=mysql_db_query($dbname,$query);
while($r=mysql_fetch_array($result))
  {
   $c502++;
   }

$fselekt=505;
$c505=0;
$sel_query="SELECT * from selekt WHERE sel_id=$fselekt";
$sel_result=mysql_db_query($dbname,$sel_query);
$sel_r=mysql_fetch_array($sel_result);
$query=$sel_r[query];
$result=mysql_db_query($dbname,$query);
while($r=mysql_fetch_array($result))
  {
   $c505++;
   }

echo "<tr>
<td colspan=\"2\"><b>ALKIS Vormigration<br>Feldvergleich Geb&auml;ude</b></td>
</tr>
<tr>
<td valign=\"top\"><small>Fluren mit Geb&auml;udebestand:</small></td>
<td align=\"right\"><b>$gebflur</b></td></tr>
<tr>
<td valign=\"top\"><small>Feldvergleich abgeschlossen</small></td>
<td align=\"right\"><b>$c51</b></td></tr>
<tr>
<td valign=\"top\"><small>noch offen:</small></td>";
$feldgeb=$gebflur-$c51;
echo "<td align=\"right\"><b>$feldgeb</b></td></tr>
<tr><td colspan=\"2\"><hr></td></tr>
<tr>
<td colspan=\"2\"><b>ALKIS Vormigration<br>Vergleich ALB-ALK</b></td>
</tr>
<tr>
<td valign=\"top\"><small>abgeschlossen</small></td>
<td align=\"right\"><b>$c56</b></td></tr>
<tr>
<td valign=\"top\"><small><a href=\"flur_selekt2.php?fselekt=57\">bereit zum Abgleich</a></small></td>
<td align=\"right\"><b>$c57</b></td></tr>
<tr>
<td valign=\"top\"><small><a href=\"flur_selekt2.php?fselekt=58\">&Uuml;berhaken entfernen</a></small></td>
<td align=\"right\"><b>$c58</b></td></tr>
<tr>
<td valign=\"top\"><small>noch offen:</small></td>";
$alkalb=$fgesamt-$c56;
echo "<td align=\"right\"><b>$alkalb</b></td></tr>
<tr><td colspan=\"2\"><hr></td></tr>
<tr>
<td colspan=\"2\"><b>Digitales Rissarchiv</b></td>
</tr>
<tr>
<td valign=\"top\"><small><a href=\"flur_selekt2.php?fselekt=500\">noch nichts erfasst</a></small></td>
<td align=\"right\"><b>$c500</b></td></tr>
<tr>
<td valign=\"top\"><small><a href=\"flur_selekt2.php?fselekt=501\">gesc. Risse erfasst<br>ohne KVZ</a></small></td>
<td align=\"right\"><b>$c501</b></td></tr>
<tr>
<td valign=\"top\"><small><a href=\"flur_selekt2.php?fselekt=503\">gesc. Risse erfasst<br>mit KVZ</a></small></td>
<td align=\"right\"><b>$c503</b></td></tr>
<tr>
<td valign=\"top\"><small><a href=\"flur_selekt2.php?fselekt=502\">Risse alle erfasst<br>ohne KVZ</a></small></td>
<td align=\"right\"><b>$c502</b></td></tr>
<tr>
<td valign=\"top\"><small><a href=\"flur_selekt2.php?fselekt=505\">Risse alle erfasst<br>mit KVZ und Anlagen</a></small></td>
<td align=\"right\"><b>$c505</b></td></tr>
</table></td></tr></table>";


nav_flur("alkgrund");
bottom();
?>