<html>
<head>
<title></title>
<meta name="author" content="Thurm">
<meta name="generator" content="Ulli Meybohms HTML EDITOR">
</head>
<body text="#000000" bgcolor="#16CD4E" link="#FF0000" alink="#FF0000" vlink="#FF0000">
<div align="center">
  <table>
    <tr>
      <td><img src="images/wappenlkm.gif" width="100" height="120" border="0" alt=""></td>
    </tr>
   </table><br>
<?php
include ("greetings.php");
?>
  <br>
<a href="home.php" target="rechts"><img src="images/buttons/home.gif" alt="" border="0" width="160"></a><br>

<a href="ant_suchen.php" target="rechts"><img src="images/buttons/vermantraege.gif" alt="" border="0" width="160"></a><br>

<a href="flur_suchen.php" target="rechts"><img src="images/buttons/fluren.gif" alt="" border="0" width="160"></a><br>

<a href="order_search.php" target="rechts"><img src="images/buttons/auftraege.gif" alt="" border="0" width="160"></a><br>

<a href="alkgeb_start.php" target="rechts"><img src="images/buttons/alkgeb.gif" alt="" border="0" width="160"></a><br>

<a href="vermst_auflistung.php" target="rechts"><img src="images/buttons/vermst.gif" alt="" border="0" width="160"></a><br>

<a href="baustellen.html" target="rechts"><img src="images/buttons/baustellen.gif" alt="" border="0" width="160"></a><br>

<a href="li_a.php" target="rechts"><img src="images/buttons/alb-listen.gif" alt="" border="0" width="160"></a><br>

<a href="vorschriften.html" target="rechts"><img src="images/buttons/vorschriften.gif" alt="" border="0" width="160"></a><br><br>

<br>
<hr>
<font face="Arial" size="-1">
Dokumentationen
<br><br>
<a href="http://gisweb2/kva/doku/INDEX.HTM" target="_blank"><img src="images/buttons/AlkAuskunft_2006.gif" alt="" border="0" width="80"></a><br><br>
<br>
<br>
<input type=button value="Zeitkonten" onClick='window.open("http://dsserv.lk-mueritz.msft/cgi-bin/htm_work.cgi")'>

</body>
</html>