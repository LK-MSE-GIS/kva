<?php
include ("connect.php");
include ("function.php");


?>

<font face="Arial"><h1>ALK-Geb&uuml;hrenrechner</h1></font>

<form action="alkgeb_result.php" method="post" target="">
<table>
<tr>
<td width="150">Kategorie</td>
<td>Anzahl m�</td>
<td>&nbsp;</td>
<td>Geb&uuml;hr in EUR</td>
</tr>
<tr>
<td colspan="4"><hr></td>
</tr>
<tr>
<td width="150">Feldlage</td>
<td><input type="int" name="areafeld" value="0" size="8" maxlength="8"></td>
<td width="80">m�</td>
</tr>
<tr>
<td width="150">Ortsrandlage</td>
<td><input type="int" name="areaorand" value="0" size="8" maxlength="8"></td>
<td>m�</td>
</tr>
<tr>
<td width="150">Ortslage</td>
<td><input type="int" name="areaort" value="0" size="8" maxlength="8"></td>
<td>m�</td>
</tr>
<tr>
<td colspan="4"><hr></td>
</tr>
<tr>
<tr>
<td>Rabatt</td>
<td><input type="int" name="rabatt" value="0" size="2" maxlength="2"></td>
<td>%</td>
</tr>
<tr>
<td colspan="4"><hr></td>
</tr>
<tr>
<td colspan="4"><input type="Submit" name="" value="Berechnen">&nbsp;&nbsp;<input type="reset"></td>
</tr>
</table>



</form>

<?php


bottom();
?>