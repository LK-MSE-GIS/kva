<?php

include("connect.php");
include("function.php");

head_flur();
nav_flur("alkgrund");

$gemkg_id=$_POST["gemkg_id"];
$flur=$_POST["flur"];
$time_von=$_POST["time_von"];
$time_bis=$_POST["time_bis"];
$datart=$_POST["datart"];
$time_von2=$_POST["time_von2"];
$time_bis2=$_POST["time_bis2"];
$datart2=$_POST["datart2"];


$query="SELECT * FROM flur ";

if(($gemkg_id>0) OR ($time_von != "")
                 OR ($time_bis != "")) $query=$query . "WHERE ";
$args=0;

if($gemkg_id>0)
  {
  $query=$query . "gemkg_id = '$gemkg_id' ";
  $args=$args+1;
  }
if($time_von != "")
  {
  if ($args>0)
    {
     $query=$query."AND ".$datart." >= '$time_von' ";
    }
    else
    {
    $query=$query.$datart." >= '$time_von' ";
    }
   $args=$args+1;
   }
if($time_bis != "")
  {
  if ($args>0)
    {
     $query=$query."AND ".$datart." <= '$time_bis' ";
    }
    else
    {
    $query=$query.$datart." <= '$time_bis' ";
    }
   $args=$args+1;
   }
 if ($datart2 == 'none')
  {
  if ((!$time_von) AND (!$time_bis))
    {
    $query=$query.";";
    }
    else
    {
     $query=$query." ORDER BY $datart,gemkg_id,flur_id";
    }
  }
  else
  {
  if($time_von2 != "") $query=$query."AND ".$datart2." >= '$time_von2'; ";
  if($time_bis2 != "") $query=$query."AND ".$datart2." <= '$time_bis2'; ";
  }



if($args>0)
{
$result=mysql_db_query($dbname,$query);
$treffer=0;
echo"<table border=\"1\" >
<tr>
 <td colspan=\"9\" align=\"center\"><marquee>Suchergebnisse</marquee> </td>
</tr>
<tr style=\"font-family:Arial; font-size: 10pt; font-weight: bold\" bgcolor=\"#80FF00\">
 <td width=\"150\">Gemarkung</td>
 <td width=\"80\">ID</td>
 <td width=\"60\">Flur</td>";
 if ($datart!='none')
  {
     $query4="SELECT * FROM abfragen WHERE variable='$datart'";
     $result4=mysql_db_query($dbname,$query4);
     $r4=mysql_fetch_array($result4);
     echo "<td>&nbsp;$r4[tabtext]&nbsp</td>";
  }
 if ($datart2!='none')
  {
     $query4="SELECT * FROM abfragen WHERE variable='$datart2'";
     $result4=mysql_db_query($dbname,$query4);
     $r4=mysql_fetch_array($result4);
     echo "<td>&nbsp;$r4[tabtext]&nbsp</td>";
  }
 echo "<td><img src=\"images/buttons/alk_grund_gray.gif\"  border=\"0\" width=\"60\"></td>
 <td><img src=\"images/buttons/alk_strha_gray.gif\"  border=\"0\" width=\"60\"></td>
  <td><img src=\"images/buttons/alk_geb_gray.gif\"  border=\"0\" width=\"60\"></td>
  <td><img src=\"images/buttons/alkis_gray.gif\"  border=\"0\" width=\"60\"></td>
  <td><img src=\"images/buttons/bos_gray.gif\"  border=\"0\" width=\"60\"></td>
  <td><img src=\"images/buttons/kvwmap_gray.gif\"  border=\"0\" width=\"60\"></td>
 </tr>";
$i=1;
while($r=mysql_fetch_array($result))
  {

  $treffer=$treffer+1;
  echo"
  <tr style=\"font-family:Arial; font-size: 10pt; font-weight: bold\">
  <td >";
     $query4="SELECT * FROM gemarkung WHERE gemark_id=$r[gemkg_id]";
     $result4=mysql_db_query($dbname,$query4);
     $r4=mysql_fetch_array($result4);
     echo"&nbsp;$r4[gemarkung]&nbsp;
  </td>
  <td>&nbsp;$r[gemkg_id]&nbsp;</td>
  <td>&nbsp;$r[flur_id]&nbsp;</td>";
  if ($datart!='none') echo "<td>&nbsp;$r[$datart]&nbsp;</td>";
  if ($datart2!='none') echo "<td>&nbsp;$r[$datart2]&nbsp;</td>";
  echo "<td>";
  if ($r[db_datum]>'0000-00-00') echo "<a href=\"flur_edit_alkgrund.php?id=$r[ID]\"><img src=\"images/buttons/haken.jpg\"  border=\"0\" width=\"60\"></a>";
  else echo "<a href=\"flur_edit_alkgrund.php?id=$r[ID]\"><img src=\"images/buttons/kreuz.jpg\"  border=\"0\" width=\"60\"></a>";
  echo "</td><td>";
  if (($r[strha_alk]=='1') AND ($r[strha_alb]=='1')OR ($r[geb]=='0')) echo "<a href=\"flur_edit_strha.php?id=$r[ID]\"><img src=\"images/buttons/haken.jpg\"  border=\"0\" width=\"60\"></a>";
  else echo "<a href=\"flur_edit_strha.php?id=$r[ID]\"><img src=\"images/buttons/kreuz.jpg\"  border=\"0\" width=\"60\"></a>";
  echo "</td><td>";
   if (($r[altgeb_db_dat]>'0000-00-00') AND ($r[geb_abschl_dat]>'0000-00-00') OR ($r[geb]=='0'))echo "<a href=\"flur_edit_geb.php?id=$r[ID]\"><img src=\"images/buttons/haken.jpg\"  border=\"0\" width=\"60\"></a>";
  else echo "<a href=\"flur_edit_geb.php?id=$r[ID]\"><img src=\"images/buttons/kreuz.jpg\"  border=\"0\" width=\"60\"></a>";
  echo "</td><td>";
   if ((($r[alkis_feld_stat]=='1') OR ($r[geb]=='0')) AND ($r[alkis_albalk_stat]=='1'))echo "<a href=\"flur_edit_alkis.php?id=$r[ID]\"><img src=\"images/buttons/haken.jpg\"  border=\"0\" width=\"60\"></a>";
  else echo "<a href=\"flur_edit_alkis.php?id=$r[ID]\"><img src=\"images/buttons/kreuz.jpg\"  border=\"0\" width=\"60\"></a>";
  echo "</td><td>";
  if (($r[bos_exists]=='1') AND ($r[bos_alk]=='1')) echo "<a href=\"flur_edit_bos.php?id=$r[ID]\"><img src=\"images/buttons/haken.jpg\"  border=\"0\" width=\"60\"></a>";
  else echo "<a href=\"flur_edit_bos.php?id=$r[ID]\"><img src=\"images/buttons/kreuz.jpg\"  border=\"0\" width=\"60\"></a>";
  echo "</td><td>";
   if (($r[all_riss_dat]>'0000-00-00') AND ($r[gesc_riss_dat]>'0000-00-00') AND ($r[gesc_riss_kvz]=='1') AND ($r[all_riss_kvz]=='1') AND ($r[anlagen_dat] > '0000-00-00'))echo "<a href=\"flur_edit_kvwmap.php?id=$r[ID]\"><img src=\"images/buttons/haken.jpg\"  border=\"0\" width=\"60\"></a>";
  else echo "<a href=\"flur_edit_kvwmap.php?id=$r[ID]\"><img src=\"images/buttons/kreuz.jpg\"  border=\"0\" width=\"60\"></a>";
  echo "</td>";

  $i=$i+1;
  }

echo "</small></table>";
echo "<br>Anzahl der Treffer: ",$treffer,"<br>";
if ($i == 1)
  {
  echo "<table>
  <tr>
 <td><h2>Leider nichts gefunden...</h2> </td>
 <td> <img src=\"images\error.jpg\" alt=\"\" border=\"0\" width=\"150\"></td>
</tr>
  </table>";
  }
}
else
{
echo "<h3>Sie haben die Suche nicht eingegrenzt !<br>Bitte geben Sie mindestens ein Suchkriterium ein.<br></h3><img src=\"images\error.jpg\" alt=\"\" border=\"0\" width=\"150\">";
}
nav_flur("alkgrund");
bottom();
?>