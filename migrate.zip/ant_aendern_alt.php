<?php
include ("connect.php");
include ("function.php");

head_ant();
nav_ant();

if ((strpos($abteilung,"grund") > -1) OR (strpos($abteilung,"adm")) > -1) $grund=1;
$id=$_GET["id"];
$page=$_GET["page"];
$nachfolger=$id+1;
$vorgaenger=$id-1;
$query="SELECT * FROM antrag WHERE id=$id";
$result=mysql_db_query($dbname,$query);
$r=mysql_fetch_array($result);
if($r[id]>0)
{
echo"
<form action=\"ant_aendern_einfuegen.php\" method=\"post\" target=\"\">
<div style=\"font-family:Arial; font-size: 10pt; font-weight: bold\">
<input type=hidden name=\"id\" value=\"$id\">";
echo "<input type=hidden name=\"page\" value=\"$page\">";
nav_aendern_g($id,$dbname,$page);
if ($grund != 1) echo "<br> Der Nutzer $username ist nicht berechtigt Grunddaten zu �ndern!<br>";
echo "<table border=\"1\">
<tr bgcolor=\"#a0a0a0\">
<td colspan=\"3\"><b>$r[number]/$r[year]</b></td>
</tr>
<tr bgcolor=\"#a0a0a0\">
 <td colspan=\"2\"> VermSt.</td>
 <td> Verm.-art</td>
</tr>
<tr>
 <td colspan=\"2\">";
 if ($grund == 1)
  {
   echo "<select name=\"vermst_id\">";

    $query2="SELECT * FROM vermst ORDER BY vermst";
    $result2=mysql_db_query($dbname,$query2);

    while($r2=mysql_fetch_array($result2))
    {
     echo "<option";
     if($r2[vermst_id] == $r[vermst_id])
      {
       echo " selected";
      }
    echo " value=\"$r2[vermst_id]\">$r2[vermst]</option>\n";
    }
     echo "
      </select> </td>";
    }
    else
    {
    $query2="SELECT * FROM vermst ORDER BY vermst";
    $result2=mysql_db_query($dbname,$query2);

    while($r2=mysql_fetch_array($result2))
      {
        if($r2[vermst_id] == $r[vermst_id]) echo "$r2[vermst]";
      }
     echo "</td>";
    }
    echo "<td> <select name=\"vermart_id\">";

 $query3="SELECT * FROM vermart ORDER BY vermart_id";
 $result3=mysql_db_query($dbname,$query3);

 while($r3=mysql_fetch_array($result3))
   {
   echo "<option";
   if($r3[vermart_id] == $r[vermart_id])
   {
   echo " selected";
   }
   echo " value=\"$r3[vermart_id]\">$r3[vermart]</option>\n";
   }
   echo "
      </select></td>
</tr>
<tr bgcolor=\"#a0a0a0\">
 <td>Gemarkung</td>
 <td>Flur</td>
 <td>Flst.</td>
</tr>
<tr>
<td><select name=\"gemark_id\">";

 $query4="SELECT * FROM gemarkung ORDER BY gemarkung";
 $result4=mysql_db_query($dbname,$query4);

 while($r4=mysql_fetch_array($result4))
   {
   echo "<option";
   if($r4[gemark_id] == $r[gemark_id])
   {
   echo " selected";
   }
   echo " value=\"$r4[gemark_id]\">$r4[gemarkung]</option>\n";
   }
   echo "
      </select>
</td>
<td><input type=\"Text\" name=\"flur\" value=\"$r[flur]\" size=\"10\" maxlength=\"10\"></td>
<td><input type=\"Text\" name=\"flst\" value=\"$r[flst]\" size=\"25\" maxlength=\"30\"></td>
</tr>
<tr bgcolor=\"#a0a0a0\">
 <td colspan=\"3\">Sachverhalt </td>
</tr>
<tr>
 <td colspan=\"3\"><input type=\"Text\" name=\"sv\" value=\"$r[sv]\" size=\"90\" maxlength=\"200\"> </td>
</tr>
<tr bgcolor=\"#a0a0a0\">
 <td>Az (Vmst.) </td>
 <td>Eilig?</td>
  <td>Eingangsdatum </td>
</tr>
<tr>
 <td> <input type=\"Text\" name=\"az\" value=\"$r[az]\" size=\"10\" maxlength=\"10\"></td>
 <td><select name=\"hurry\">
   <option";
    if($r[hurry]=="1")
    {
    echo " selected";
    }
    echo " value=\"1\">ja</option>
   <option";
   if($r[hurry]=="0")
    {
    echo " selected";
    }
    echo " value=\"0\">nein</option>

   </select></td>
 <td><input type=\"date\" name=\"eing_datum\" value=\"$r[eing_datum]\" size=\"10\" maxlength=\"10\"> </td>
</tr>
<tr bgcolor=\"#a0a0a0\">
 <td colspan=\"3\">Wo ist die Akte? </td>

</tr>
<tr>
 <td colspan=\"3\"><select name=\"aktort_id\">";

 $query5="SELECT * FROM aktort ORDER BY aktort_id";
 $result5=mysql_db_query($dbname,$query5);

 while($r5=mysql_fetch_array($result5))
   {
   echo "<option";
   if($r5[aktort_id] == $r[aktort_id])
   {
   echo " selected";
   }
   echo " value=\"$r5[aktort_id]\">$r5[aktort]</option>\n";
   }
   echo "
      </select>
 </td>

</tr>";
if ($grund == 1)
 {
  echo "<tr>
  <td colspan=\"3\" bgcolor=\"#a0a0a0\"> <input type=\"Submit\" name=\"\" value=\"&Auml;nderungen eintragen\">&nbsp;&nbsp;<input type=\"reset\">&nbsp;
  </td>
  </tr>";
  }
 echo "</table>";
}
else
{
echo "<h3>Die Antragsnummer --> ",$id," <-- ist (noch) nicht vergeben..</h3>";
}
echo "</form>
<table border=\"0\">
<tr><td>";
echo "<a href=\"ant_searchlist.php?page=$page&highlight=$id\"><img src=\"images/buttons/back.png\" alt=\"Zur&uuml;ck zur aktuellen Suche\" border=\"0\" width=\"120\"></a>&nbsp;&nbsp;";
echo "</td><td>";


echo "<a href=\"ant_aendern.php?id=$vorgaenger&page=$page\"><img src=\"images/buttons/pfeil_links.png\" alt=\"\" border=\"0\" width=\"80\"></a>
 <a href=\"ant_aendern.php?id=$nachfolger&page=$page\"><img src=\"images/buttons/pfeil_rechts.png\" alt=\"\" border=\"0\" width=\"80\"></a></td></tr></table>";
nav_ant();
bottom();
?>