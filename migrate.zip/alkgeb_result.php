<?php
include ("connect.php");
include ("function.php");

$areafeld=$_POST["areafeld"];
$areaorand=$_POST["areaorand"];
$areaort=$_POST["areaort"];
$rabatt=$_POST["rabatt"];

$feldgeb=$areafeld*50/250000;
$feldgeb=round($feldgeb,2);
$orandgeb=$areaorand*305/250000;
$orandgeb=round($orandgeb,2);
$ortgeb=$areaort*610/250000;
$ortgeb=round($ortgeb,2);
$gesamtbrutto=$feldgeb+$orandgeb+$ortgeb;
$gesamtbrutto=round($gesamtbrutto,2);
$rabattbetrag=$gesamtbrutto*$rabatt/100;
$rabattbetrag=round($rabattbetrag,2);
$gesamtnetto=$gesamtbrutto-$rabattbetrag;
$gesamtnetto=round($gesamtnetto,2);

?>

<font face="Arial"><h1>ALK-Geb&uuml;hrenrechner</h1></font>
<form action="alkgeb_result_print.php" method="post" target="">
<?php
 echo "<input type=\"hidden\" name=\"feldgeb\" value=\"$feldgeb\" >
<input type=\"hidden\" name=\"orandgeb\" value=\"$orandgeb\">
<input type=\"hidden\" name=\"ortgeb\" value=\"$ortgeb\">
<input type=\"hidden\" name=\"areafeld\" value=\"$areafeld\">
<input type=\"hidden\" name=\"areaorand\" value=\"$areaorand\">
<input type=\"hidden\" name=\"areaort\" value=\"$areaort\">
<input type=\"hidden\" name=\"rabatt\" value=\"$rabatt\">
<input type=\"hidden\" name=\"rabattbetrag\" value=\"$rabattbetrag\">
<input type=\"hidden\" name=\"gesamtnetto\" value=\"$gesamtnetto\">
<input type=\"hidden\" name=\"gesamtbrutto\" value=\"$gesamtbrutto\">";
?>
<table>
<tr>
<td width="150">Kategorie</td>
<td>Anzahl m�</td>
<td>&nbsp;</td>
<td>Geb&uuml;hr in EUR</td>
</tr>
<tr>
<td colspan="4"><hr></td>
</tr>

<?php
echo "<tr><td width=\"150\">Feldlage</td>
<td><input type=\"int\" name=\"areafeld\" value=\"$areafeld\" size=\"8\" maxlength=\"8\"></td>
<td width=\"80\">m�</td>
<td align=\"right\">$feldgeb</td>
</tr>";
echo "<tr><td width=\"150\">Ortsrandlage</td>
<td><input type=\"int\" name=\"areaorand\" value=\"$areaorand\" size=\"8\" maxlength=\"8\"></td>
<td width=\"80\">m�</td>
<td align=\"right\">$orandgeb</td>
</tr>";
echo "<tr><td width=\"150\">Ortslage</td>
<td><input type=\"int\" name=\"areaort\" value=\"$areaort\" size=\"8\" maxlength=\"8\"></td>
<td width=\"80\">m�</td>
<td align=\"right\">$ortgeb</td>
</tr>";
?>
<tr><td colspan="4"><hr></td></tr>
<?php
echo "<tr>
<td>Summe</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td align=\"right\">$gesamtbrutto</td>
</tr>";
echo "<tr>
<td>Rabatt ($rabatt %)</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td align=\"right\">-&nbsp;$rabattbetrag</td>
</tr>";
echo "<tr>
<td>Gesamt</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td align=\"right\">$gesamtnetto</td>
</tr>";
?>
<tr>
<td colspan="4"><hr></td>
</tr>
<tr>
<td colspan="4">Angaben zum Empf&auml;nger (optional)</td>
</tr>
<tr>
<td colspan="4"><input type="Text" name="add1" value="" size="50" maxlength="50"></td> </tr><tr>
<td colspan="4"><input type="Text" name="add2" value="" size="50" maxlength="50"></td>  </tr><tr>
<td colspan="4"><input type="Text" name="add3" value="" size="50" maxlength="50"></td>  </tr><tr>
<td colspan="4"><input type="Text" name="add4" value="" size="50" maxlength="50"></td>   </tr><tr>
<td colspan="4"><input type="Text" name="add5" value="" size="50" maxlength="50"></td>
</tr>
<tr>
<td colspan="4"><hr></td>
</tr>
<tr>
<td colspan="4">Betreff (optional)</td>
</tr>
<tr>
<td colspan="4"><input type="Text" name="betreff" value="" size="50" maxlength="50"></td> </tr>
<tr>
<td colspan="4"><a href="alkgeb_start.php">Neue Berechnung</a>&nbsp;&nbsp;&nbsp;<input type="Submit" name="" value="Druckversion"></td>
</tr>
</table>
</form>




<?php


bottom();
?>