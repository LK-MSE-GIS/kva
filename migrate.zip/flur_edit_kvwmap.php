<?php
include ("connect.php");
include ("function.php");

head_flur();
nav_flur("kvwmap");

$id=$_GET["id"];
$nachfolger=$id+1;
$vorgaenger=$id-1;
$query="SELECT * FROM flur WHERE ID=$id";
$result=mysql_db_query($dbname,$query);
$r=mysql_fetch_array($result);

flur_kopf($id,$dbname);
navi_flur("kvwmap",$id);
abhaken($r[ID],$dbname,"80",0);

 echo"</table>";
echo "<form action=\"flur_ins_kvwmap.php\" method=\"post\" target=\"\">
<input type=hidden name=\"id\" value=\"$id\">";


echo "<br><table border=\"1\">
<tr style=\"font-family:Arial; font-size: 10pt; font-weight: bold\">
<td  bgcolor=\"#F17533\" colspan=\"2\">Rissarchivierung (kvwmap)</td>
<td bgcolor=\"#F17533\">mit KVZ</td>
<td bgcolor=\"#F17533\">Mitarbeiter</td>
</tr>
<tr>
<td  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\" width=\"300\" bgcolor=\"#F17533\">gescannte Risse (aus GDS) erfasst:</td>
<td><input  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\" type=\"date\" name=\"gesc_riss_dat\" value=\"$r[gesc_riss_dat]\" size=\"10\" ></td>
<td><select  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\" name=\"gesc_riss_kvz\">
   <option style=\"font-family:Arial; font-size: 10pt; font-weight: bold\"";
   if($r[gesc_riss_kvz]==0)
    {
    echo " selected";
    }
    echo " value=\"0\">nein</option>
   <option style=\"font-family:Arial; font-size: 10pt; font-weight: bold\"";
   if($r[gesc_riss_kvz]==1)
    {
    echo " selected";
    }
    echo " value=\"1\">ja</option>
    </select></td>
    <td>
    <select  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\"        name=\"gesc_riss_mitid\">";

 $query10="SELECT * FROM mitarbeiter WHERE abteilung LIKE '%ris%'";
 $result10=mysql_db_query($dbname,$query10);

 while($r10=mysql_fetch_array($result10))
   {
   echo "<option style=\"font-family:Arial; font-size: 10pt; font-weight: bold\"";
   if($r10[mitarb_id] == $r[gesc_riss_mitid])
   {
   echo " selected";
   }
   echo " value=\"$r10[mitarb_id]\">$r10[name]</option>\n";
   }
   echo "
      </select>
   </td>
</tr>
<tr>
<td  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\" width=\"300\" bgcolor=\"#F17533\">Risse komplett erfasst:</td>
<td><input  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\" type=\"date\" name=\"all_riss_dat\" value=\"$r[all_riss_dat]\" size=\"10\" ></td>
<td><select  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\" name=\"all_riss_kvz\">
   <option style=\"font-family:Arial; font-size: 10pt; font-weight: bold\"";
   if($r[all_riss_kvz]==0)
    {
    echo " selected";
    }
    echo " value=\"0\">nein</option>
   <option style=\"font-family:Arial; font-size: 10pt; font-weight: bold\"";
   if($r[all_riss_kvz]==1)
    {
    echo " selected";
    }
    echo " value=\"1\">ja</option>
    </select></td>
    <td>
    <select  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\"        name=\"all_riss_mitid\">";

 $query10="SELECT * FROM mitarbeiter WHERE abteilung LIKE '%ris%'";
 $result10=mysql_db_query($dbname,$query10);

 while($r10=mysql_fetch_array($result10))
   {
   echo "<option style=\"font-family:Arial; font-size: 10pt; font-weight: bold\"";
   if($r10[mitarb_id] == $r[all_riss_mitid])
   {
   echo " selected";
   }
   echo " value=\"$r10[mitarb_id]\">$r10[name]</option>\n";
   }
   echo "
      </select>
   </td>
</tr>
<tr>
<td  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\" width=\"300\" bgcolor=\"#F17533\">Anlagen erfasst am:</td>
<td colspan=\"2\"><input  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\" type=\"date\" name=\"anlagen_dat\" value=\"$r[anlagen_dat]\" size=\"10\" ></td>
<td>
    <select  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\"        name=\"anlagen_mitid\">";

 $query10="SELECT * FROM mitarbeiter WHERE abteilung LIKE '%ris%'";
 $result10=mysql_db_query($dbname,$query10);

 while($r10=mysql_fetch_array($result10))
   {
   echo "<option style=\"font-family:Arial; font-size: 10pt; font-weight: bold\"";
   if($r10[mitarb_id] == $r[anlagen_mitid])
   {
   echo " selected";
   }
   echo " value=\"$r10[mitarb_id]\">$r10[name]</option>\n";
   }
   echo "
      </select>
   </td>
</tr>
<tr>
<td  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\" width=\"300\" bgcolor=\"#F17533\">alte Risse georeferenziert am:</td>
<td colspan=\"2\"><input  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\" type=\"date\" name=\"georef_dat\" value=\"$r[georef_dat]\" size=\"10\" ></td>
<td>
    <select  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\"        name=\"georef_mitid\">";

 $query10="SELECT * FROM mitarbeiter WHERE abteilung LIKE '%ris%'";
 $result10=mysql_db_query($dbname,$query10);

 while($r10=mysql_fetch_array($result10))
   {
   echo "<option style=\"font-family:Arial; font-size: 10pt; font-weight: bold\"";
   if($r10[mitarb_id] == $r[georef_mitid])
   {
   echo " selected";
   }
   echo " value=\"$r10[mitarb_id]\">$r10[name]</option>\n";
   }
   echo "
      </select>
   </td>
</tr>
</table>

<br>
<input  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\" type=\"Submit\" value=\"&Auml;nderungen eintragen\">&nbsp;<input  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\" type=\"reset\">";
echo "</form>";
echo "<br><br>";
echo "<a  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\" href=\"flur_edit_kvwmap.php?id=$vorgaenger\"><img src=\"images/buttons/pfeil_links.png\" alt=\"\" border=\"0\" width=\"120\"</a>&nbsp;&nbsp;
 <a  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\" href=\"flur_edit_kvwmap.php?id=$nachfolger\"><img src=\"images/buttons/pfeil_rechts.png\" alt=\"\" border=\"0\" width=\"120\"</a></a></a></a></div><br> <br> ";


nav_flur("kvwmap");
bottom();
?>