<!-- saved from url=(0022)http://internet.e-mail -->
<?php
    include("connect.php");

    $datum = getdate(time());
    $year=$datum[year];
    $month=$datum[mon];
    $day=$datum[mday];
    $wday=$datum[wday];
    if ($wday=='0') $wochentag="Sonntag";
    if ($wday=='1') $wochentag="Montag";
    if ($wday=='2') $wochentag="Dienstag";
    if ($wday=='3') $wochentag="Mittwoch";
    if ($wday=='4') $wochentag="Donnerstag";
    if ($wday=='5') $wochentag="Freitag";
    if ($wday=='6') $wochentag="Sonnabend";
    if (strlen($month) == 1) $month='0'.$month;
    if (strlen($day) == 1) $day='0'.$day;
    if (strlen($sec) == 1) $sec='0'.$sec;
    $print_datum=$day.".".$month.".".$year;
    $bday_datum=$month."-".$day;

?>
<html>
<head>
<title>Katasteramt</title>
<meta name="author" content="Thurm">
<meta name="generator" content="Ulli Meybohms HTML EDITOR">
</head>
<body text="#000000" bgcolor="#FFFFFF" link="#FF0000" alink="#FF0000" vlink="#FF0000">

<font face="Arial">
<hr>
<table>
<tr>
<td align="left" rowspan="2"><img src="images/amt.jpg" alt="" border="0" width="300">&nbsp;<img src="images/buttons/bornsee.jpg" alt="" border="0" width="365">&nbsp;</td><td><font size="+2"><?php echo $wochentag; ?></font></td></tr>
<tr><td><font size="+5"><?php echo $print_datum; ?></font></td>
</tr>
</table>
<hr>
<table>
<tr>
<td width="300" valign="top">
<table border="0" bgcolor="#CCC280">
<tr>
<td><b>Wer hat heute Geburtstag?</b></td>
</tr>
<?php
$query="SELECT * from birthday where date='$bday_datum'";
$result=mysql_db_query($dbname,$query);
while($r=mysql_fetch_array($result))
  {
   $age=$year-$r[byear];
   if ($r[byear]=='') $age='??';
   echo "<tr><td>$r[name]($age)</td></tr>
   <tr><td><small>$r[whoisit]</td></tr>";
  }
?>
</table><br>


<table border="0">
<tr><td><hr></td></tr>
<tr>
 <td width="300" align="left"><marquee>Neuigkeiten </marquee></td>
</tr>
<tr>
<td><hr></td>
</tr>
<tr>
 <td align="left"><font size="-1">2007-22-11</font></td>
 </tr>
 <tr>
 <td textcolor="red">Weihnachtsfeier am 11. Dezember<br><br>
 </td>
 </tr>
 <tr>
 <td><font size="-1">Am 11. Dezember findet im Sch�tzenhaus in den Kirchtannen die diesj�hrige Weihnachtsfeier des Kataster- und Vermessungsamtes statt. Dieses Jahr steht sie unter dem Motto <b>Lass dich &uuml;berraschen</b>. Im Archiv h�ngt ein Plakat mit n&auml;heren Informationen und einer Liste, in welcher sich die Teilnehmer eintragen k�nnen.<br><br>

 <img src="images/weihnachtsfeier.jpg" alt="" border="1" width="300"></font><br>
 </td>
 </tr>
 <tr>
<td><hr></td>
</tr>
<tr>
 <td align="left"><font size="-1">2007-10-01</font></td>
 </tr>
 <tr>
 <td textcolor="red">Ab Oktober neue Version von kvwmap und neue Passworte<br><br>
 </td>
 </tr>
 <tr>
 <td><font size="-1">Ab dem 01.10. steht die Version 1.66 allen Mitarbeitern des Kataster- und Vermessungsamtes zur Verf�gung. Auf der Startseite des Geoinformationsportals ist ein dementsprechender Link vorhanden. Im Zusammenhang damit ist es notwendig neue Passworte einzuf�hren. Dieses neue Passwort gilt dann sowohl f�r kvwmap (auch f�r die alte Version) als auch f�r die Seite des Katasteramtes. Jeder Mitarbeiter erh�lt eine E-Mail sobald sein Passwort ge�ndert wurde. Das neue Passwort kann dann wie �blich gespeichert werden. Informationen zur neuen Version von kvwmap gibt es auf den Seite des Geoinformationsportals.</font><br>
 </td>
 </tr>
<tr>
 <td align="left"><font size="-1">2007-08-22</font></td>
 </tr>
   <tr>
<td><hr></td>
</tr>
 <tr>
 <td textcolor="red">Aktuelle Vorschriften als PDF<br><br>
 </td>
 </tr>
 <tr>
 <td><font size="-1">Unter dem neuen Men�punkt <b>Vorschriften</b> sind einige der wiichtigsten Dokumente wie zum Beispiel der OBAK und der OSKA als PDF-Dokumente in der jeweils aktuellen Fassung verf�gbar.</font><br>
 </td>
 </tr>
 </table>
 </div></td>
 <td>&nbsp;&nbsp;</td>
 <td width="700" valign="top">
 <font face="Arial"><font size="+2">
 Tino Eisbrenner in R&ouml;bel<br>
 <font size="-1">Der Rockpoet vom Vier Winde Hof startete seine Kirchentour in der Alten Synagoge in R&ouml;bel.</font>

<table cellspacing="10">
<tr>
<td colspan="2"><img src="images/2007-11-26_eisbrenner1.jpg" width="700" alt="" border="1"></td>
</tr>
<tr>
<td><img src="images/2007-11-26_eisbrenner2.jpg" width="344" alt="" border="1"></td>
<td><img src="images/2007-11-26_eisbrenner3.jpg" width="344" alt="" border="1"></td>
</tr>
<tr>
<td colspan="2"><img src="images/2007-11-26_eisbrenner4.jpg" width="700" alt="" border="1"></td>
</tr>
</table>
</body>
</html>