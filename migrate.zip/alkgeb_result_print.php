<?php
include ("connect.php");
include ("function.php");

$areafeld=$_POST["areafeld"];
$areaorand=$_POST["areaorand"];
$areaort=$_POST["areaort"];
$rabatt=$_POST["rabatt"];

$feldgeb=$_POST["feldgeb"];
$orandgeb=$_POST["orandgeb"];
$ortgeb=$_POST["ortgeb"];
$gesamtbrutto=$_POST["gesamtbrutto"];
$rabattbetrag=$_POST["rabattbetrag"];
$gesamtnetto=$_POST["gesamtnetto"];
$add1=$_POST["add1"];
$add2=$_POST["add2"];
$add3=$_POST["add3"];
$add4=$_POST["add4"];
$add5=$_POST["add5"];
$betreff=$_POST["betreff"];
?>

<table>
<tr>
<td rowspan="3" width="100"><img src="images/wappen.png" alt="" border="0" width="100"></td>
<td width="400" align="right" style="font-family:Arial; font-size: 28pt; font-weight: bold">Landkreis M&uuml;ritz</td>
</tr>
<tr>
<td valign="top" align="right" style="font-family:Arial; font-size: 14pt; font-weight: bold">Die Landr&auml;tin</td>
</tr>
<tr>
<td valign="top" align="right" style="font-family:Arial; font-size: 10pt; font-weight: bold">Zum Amtsbrink 2<br>17192 Waren(M&uuml;ritz)</td>
</tr>
</table>
<br>
<br>

<?php
 echo "<table>
<tr>
<td width=\"300\">";
if ($add1 !="") echo "<font size=\"-1\">Empf&auml;nger:</font><br>";
echo "$add1<br>";
echo "$add2<br>";
echo "$add3<br>";
echo "$add4<br>";
echo "$add5<br>";
 echo "</td>
 <td valign=\"top\">Datum:<br>Bearbeiter:</td>
 <td align=\"right\" valign=\"top\">$print_datum<br>
  $username</td>
</tr>
</table>";
?>
<font face="Arial">ALK-Geb&uuml;hrenberechnung</font><br>
<font size="-1">nach Tarifstelle:3.5.1.1.(2. Geb&Auml;VO M-V)</font><br>
<br>
<?php
  if ($betreff != "")
     {
      echo "Betreff: $betreff<br><br>";
     }
?>
<table>
<tr>
<td width="150">Kategorie</td>
<td>Anzahl m�</td>
<td>&nbsp;</td>
<td>Geb&uuml;hr in EUR</td>
</tr>
<tr>
<td colspan="4"><hr></td>
</tr>

<?php
echo "<tr><td width=\"150\">Feldlage<br>
</td>
<td>$areafeld</td>
<td width=\"80\">m�</td>
<td align=\"right\">$feldgeb</td>
</tr>";
echo "<tr><td width=\"150\">Ortsrandlage</td>
<td>$areaorand</td>
<td width=\"80\">m�</td>
<td align=\"right\">$orandgeb</td>
</tr>";
echo "<tr><td width=\"150\">Ortslage</td>
<td>$areaort</td>
<td width=\"80\">m�</td>
<td align=\"right\">$ortgeb</td>
</tr>";
?>
<tr><td colspan="4"><hr></td></tr>
<?php

if ($rabatt > 0)
 {
   echo "<tr>
   <td>Summe</td>
   <td>&nbsp;</td>
   <td>&nbsp;</td>
   <td align=\"right\">$gesamtbrutto</td>
   </tr>";
  }
if ($rabatt > 0)
  {
   echo "<tr>
   <td>Rabatt ($rabatt %)</td>
   <td>&nbsp;</td>
   <td>&nbsp;</td>
   <td align=\"right\">-&nbsp;$rabattbetrag</td>
   </tr>";
   }
echo "<tr>
<td>Gesamt</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td align=\"right\">$gesamtnetto</td>
</tr>";
?>
<tr>
<td colspan="4"><hr></td>
</tr>
</table>





<?php


bottom();
?>