<?php
include ("connect.php");


?>

<form action="news_insert.php" method="post" target="">
Neue News eintragen

<table border="1" >

<tr>
 <td bgcolor="#a0a0a0" >Absender:</td>
 <td><input type="Text" name="author" value="" size="50" maxlength="50"> </td>
 </tr>
<tr>
<td bgcolor="#a0a0a0">Titel:</td>
<td><input type="text" name="titel" value="" size="80" maxlength="80"></td>
</tr>
<tr >
 <td bgcolor="#a0a0a0" colspan="2">Text:</td>
</tr>
<tr>
<td colspan="2"><textarea name="message" cols="65" rows="10"></textarea></td>
</tr>
<tr>
 <td colspan="2" bgcolor="#a0a0a0"> <input type="Submit" name="" value="Senden">&nbsp;&nbsp;<input type="reset"></td>
</tr>
</table>
</form>
</body>
