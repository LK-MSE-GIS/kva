<?php
include ("connect.php");
include ("function.php");

head_flur();
nav_flur("alkgrund");
?>

<font face="Arial"><h1>Flurdatenbank</h1></font>

<form action="flur_suchen_id.php" method="post" target="">
<table border="1" >
<tr bgcolor="#80FF00">
 <td>Gemarkung ausw�hlen</td>
 <td>Zeitraum eingrenzen</td>
 <td>von</td>
 <td>bis</td>
 </tr>
<tr>
<td> <select name="gemkg_id">
 <?php
 $query="SELECT * FROM gemarkung ORDER BY gemarkung";
 $result=mysql_db_query($dbname,$query);

 while($r=mysql_fetch_array($result))
   {
   echo "<option value=\"$r[gemark_id]\">$r[gemarkung]</option>\n";
   }
?>
</select>
 </td>
 <td><select name="datart" size="">
 <?php
 $query="SELECT * FROM abfragen ORDER BY id";
 $result=mysql_db_query($dbname,$query);

 while($r=mysql_fetch_array($result))
   {
   echo "<option value=\"$r[variable]\">$r[tabtext]</option>\n";
   }
?>
</select></td>
 <td><input type="date" name="time_von" value="" size="10" maxlength="10"></td>
 <td><input type="date" name="time_bis" value="" size="10" maxlength="10"></td>
</tr>
<tr>
<td>
 </td>
 <td><select name="datart2" size="">
 <?php
 $query="SELECT * FROM abfragen ORDER BY id";
 $result=mysql_db_query($dbname,$query);

 while($r=mysql_fetch_array($result))
   {
   echo "<option value=\"$r[variable]\">$r[tabtext]</option>\n";
   }
?>
 </select></td>
 <td><input type="date" name="time_von2" value="" size="10" maxlength="10"></td>
 <td><input type="date" name="time_bis2" value="" size="10" maxlength="10"></td>
</tr>
<tr>
 <td colspan="2" bgcolor="#80FF00"> <input type="Submit" name="" value="Suche starten">&nbsp;&nbsp;<input type="reset"></td>

</tr>
</table>
</form>
<br>
<br>



<?php

nav_flur("alkgrund");
bottom();
?>