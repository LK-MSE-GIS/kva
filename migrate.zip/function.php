<?php

    $datum = getdate(time());
    $year=$datum[year];
    $month=$datum[mon];
    $day=$datum[mday];
    $hour=$datum[hours];
    $min=$datum[minutes];
    $sec=$datum[seconds];

    if (strlen($month) == 1) $month='0'.$month;
    if (strlen($day) == 1) $day='0'.$day;
    if (strlen($hour) == 1) $hour='0'.$hour;
    if (strlen($min) == 1) $min='0'.$min;
    if (strlen($sec) == 1) $sec='0'.$sec;
    $print_datum=$year."-".$month."-".$day;



function head_vermst()
 {
  echo " <html>
  <head>
  <meta http-equiv=\"pragma\" content=\"nocache\">
  <title>
    Vermessungsstellen
  </title>
  </head>

  <body bgcolor=\"#FDFFEE\">
<h3 align=\"center\">Vermessungsstellen</h3>";
}

function head_order()
 {
  echo " <html>
  <head>
  <meta http-equiv=\"pragma\" content=\"nocache\">
  <title>
    Auftragsdatenbank
  </title>
  </head>

  <body bgcolor=\"#FDFFEE\">
<h3 align=\"center\">Auftr&auml;ge</h3>";
}

function nav_vermst()
  {
 echo "<table width=\"100%\" border=\"0\">
<tr style=\"font-family:Arial; font-size: 12pt; font-weight: bold\">
 <td> [ <a href=\"vermst_auflistung.php\">Auflistung</a>]
      [ <a href=\"vermst_eintrag.php\">Neuer Eintrag</a>]
      [ <a href=\"ant_suchen.php\">Antragsverwaltung</a>]

</tr>
</table>
<hr>";
}

function nav_orders()
  {
 echo "<table width=\"100%\" border=\"0\">
<tr style=\"font-family:Arial; font-size: 12pt; font-weight: bold\">
 <td> [ <a href=\"order_new.php\">Neuer Auftrag</a>]
      [ <a href=\"order_search.php\">Auftrag suchen</a>]
      [ <a href=\"ant_suchen.php\">Antragsverwaltung</a>]
</tr>
</table>
<hr>";
}

function head_ant()
 {
  echo " <html>
  <head>
  <meta http-equiv=\"pragma\" content=\"nocache\">
  <title>
    Antragsdatenbank Katasteramt
  </title>
  </head>

  <body bgcolor=\"#FCFCFC\">";
}

function nav_ant()
  {
 echo "<table width=\"100%\" border=\"0\">
<tr style=\"font-family:Arial; font-size: 12pt; font-weight: bold\">
 <td> [ <a href=\"ant_suchen.php\">Suche</a>]
      [ <a href=\"ant_eintrag.php\">Neuer Eintrag</a>]
      [ <a href=\"ant_status.php\">&Uuml;bersicht</a>]
      [ <a href=\"vermst_auflistung.php\">Vermessungsstellen</a>]
      [ <a href=\"ant_statistik_quest.php\">Statistik</a>]
      [ <a href=\"flur_suchen.php\">Flurdatenbank</a>]

</tr>
</table>
<hr>";
}

function nav_aendern($id,$dbname,$page)
 {

  $query="SELECT o.*, x.* FROM antrag as o, antrag_extra as x WHERE o.id=$id AND o.id=x.id";
  $result=mysql_db_query($dbname,$query);
  $r=mysql_fetch_array($result);

  echo" <table border=\"0\" >
  <tr>

  <td><a href=\"ant_searchlist.php?page=$page&highlight=$id\"><img src=\"images/buttons/back.png\" alt=\"Zur&uuml;ck zur aktuellen Suche\" border=\"0\" width=\"80\"></a></td>

  <td>
  <a href=\"ant_aendern.php?id=$id&page=$page\">";
  if (($r[vermst_id]>0) AND ($r[vermart_id] !=0) AND ($r[gemark_id_1] > 0)) echo "<img src=\"images/buttons/g_green.gif\"  border=\"0\" width=\"120\">";
  else  echo "<img src=\"images/buttons/g_red.gif\"  border=\"0\" width=\"120\">";
  echo "</a></td>


  <td>
  <a href=\"ant_aendern_vorb.php?id=$id&page=$page\">";
  if ($r[vorb_ja_nein]>0) echo "<img src=\"images/buttons/v_green.gif\"  border=\"0\" width=\"120\">";
  else  echo "<img src=\"images/buttons/v_red.gif\"  border=\"0\" width=\"120\">";
  echo "</a></td>


  <td>
  <a href=\"ant_aendern_me.php?id=$id&page=$page\">";
  if (($r[me_ja_nein]>0) OR ($r[vermart_id]=='10')) echo "<img src=\"images/buttons/m_green.gif\"  border=\"0\" width=\"120\">";
  else  echo "<img src=\"images/buttons/m_red.gif\"  border=\"0\" width=\"120\">";
  echo "</a></td>


  <td>
  <a href=\"ant_aendern_uebernahme.php?id=$id&page=$page\">";
  if (($r[alb_ja_nein]>0) AND ($r[alk_ja_nein]>0) AND ($r[ueb_ja_nein]>0)OR ($r[vermart_id]=='10')) echo "<img src=\"images/buttons/u_green.gif\"  border=\"0\" width=\"120\">";
  else  echo "<img src=\"images/buttons/u_red.gif\"  border=\"0\" width=\"120\">";
  echo "</a></td>

  <td>
  <a href=\"ant_aendern_rech.php?id=$id&page=$page\">";
  if (($r[re_ja_nein]>0) OR ($r[vermart_id]=='10')) echo "<img src=\"images/buttons/r_green.gif\"  border=\"0\" width=\"120\">";
  else  echo "<img src=\"images/buttons/r_red.gif\"  border=\"0\" width=\"120\">";
  echo "</a></td>

  </tr></table><br>";
}



function nav_aendern_ueb($id,$dbname,$page)
{
echo "<table border=\"0\" >
<tr>
 <td><a href=\"ant_aendern.php?id=$id&page=$page\"><img src=\"images/buttons/grunddaten.png\"  border=\"0\" width=\"120\"></a></td>
 <td>&nbsp;</td>
 <td><a href=\"ant_aendern_vorb.php?id=$id&page=$page\"><img src=\"images/buttons/vorbereitung.png\"  border=\"0\" width=\"120\"></a></td>
 <td>&nbsp;</td>
  <td><a href=\"ant_aendern_me.php?id=$id&page=$page\"><img src=\"images/buttons/messeingang.png\"  border=\"0\" width=\"120\"></a></td>
  <td>&nbsp;</td>
  <td><img src=\"images/buttons/uebernahmealk.png\"  border=\"0\" width=\"160\"></td>
  <td>&nbsp;</td>
  <td><a href=\"ant_aendern_rech.php?id=$id&page=$page\"><img src=\"images/buttons/bill.png\"  border=\"0\" width=\"120\"></a></td>
    <td>&nbsp;</td>
  <td><a href=\"ant_overview.php?id=$id&page=$page\"><img src=\"images/buttons/uebersicht.png\"  border=\"0\" width=\"120\"></a></td>
</tr>";
include ("ant_abhaken.php");
}


function nav_aendern_re($id,$dbname,$page)
 {
 echo" <table border=\"0\" >
<tr>
 <td><a href=\"ant_aendern.php?id=$id&page=$page\"><img src=\"images/buttons/grunddaten.png\"  border=\"0\" width=\"120\"></a></td>
 <td>&nbsp;</td>
 <td><a href=\"ant_aendern_vorb.php?id=$id&page=$page\"><img src=\"images/buttons/vorbereitung.png\"  border=\"0\" width=\"120\"></a></td>
 <td>&nbsp;</td>
 <td><a href=\"ant_aendern_me.php?id=$id&page=$page\"><img src=\"images/buttons/messeingang.png\"  border=\"0\" width=\"120\"></a></td>
 <td>&nbsp;</td>
  <td><a href=\"ant_aendern_uebernahme.php?id=$id&page=$page\"><img src=\"images/buttons/uebernahmealk.png\"  border=\"0\" width=\"120\"></a></td>
  <td>&nbsp;</td>
<td><img src=\"images/buttons/bill.png\"  border=\"0\" width=\"160\"></td>
  <td>&nbsp;</td>
  <td><a href=\"ant_overview.php?id=$id&page=$page\"><img src=\"images/buttons/uebersicht.png\"  border=\"0\" width=\"120\"></a></td>
</tr>";
$query="SELECT * FROM antrag WHERE id=$id;";
$result=mysql_db_query($dbname,$query);
$r=mysql_fetch_array($result);
echo "<tr><td>";
include ("ant_abhaken.php");
  }

function nav_aendern_o($id)
 {
 echo" <table border=\"0\" >
<tr>
 <td><a href=\"ant_aendern.php?id=$id\"><img src=\"images/buttons/grunddaten.png\"  border=\"0\" width=\"120\"></a></td>
 <td>&nbsp;</td>
 <td><a href=\"ant_aendern_vorb.php?id=$id\"><img src=\"images/buttons/vorbereitung.png\"  border=\"0\" width=\"120\"></a></td>
 <td>&nbsp;</td>
 <td><a href=\"ant_aendern_me.php?id=$id\"><img src=\"images/buttons/messeingang.png\"  border=\"0\" width=\"120\"></a></td>
 <td>&nbsp;</td>
  <td><a href=\"ant_aendern_uebernahme.php?id=$id\"><img src=\"images/buttons/uebernahmealk.png\"  border=\"0\" width=\"120\"></a></td>
  <td>&nbsp;</td>
  <td><a href=\"ant_aendern_rech.php?id=$id\"><img src=\"images/buttons/bill.png\"  border=\"0\" width=\"120\"></a></td>
  <td>&nbsp;</td>
  <td><img src=\"images/buttons/uebersicht.png\"  border=\"0\" width=\"160\"></td>
</tr>
</table><br>";
  }


function head_flur()
 {
  echo " <html>
  <head>
  <meta http-equiv=\"pragma\" content=\"nocache\">
  <title>
    Flurdatenbank Katasteramt
  </title>
  </head>

  <body bgcolor=\"#FFFEF4\">";
}

function nav_flur($direction)
  {
  if ($direction == "kvwmap") $dirlink="flur_search_kvwmap.php";
  if ($direction == "alkgrund") $dirlink="flur_search_alkgrund.php";
  if ($direction == "geb") $dirlink="flur_search_geb.php";
  if ($direction == "strha") $dirlink="flur_search_strha.php";
  if ($direction == "alkis") $dirlink="flur_search_alkis.php";
  if ($direction == "bos") $dirlink="flur_search_bos.php";

 echo "<table width=\"100%\" border=\"0\">
<tr>
 <td style=\"font-family:Arial; font-size: 10pt; font-weight: bold\"> [ <a href=\"flur_suchen.php\">Flur suchen</a>]&nbsp;[ <a href=$dirlink>Flur suchen nach Themen </a>]&nbsp;[ <a href=\"flur_statistik.php\">Statistik</a>]&nbsp;
[ <a href=\"ant_suchen.php\">Antragsdatenbank</a>]

</tr>
</table>
<hr>";
}


function ok()
  {
  echo "<img src=\"images/ok.jpg\" alt=\"\" border=\"0\"><br><br>";
  }
function error()
  {
  echo "<img src=\"images/error.jpg\" alt=\"\" width=\"150\" border=\"0\"><br><br>";
  }

function bottom()
  {
  echo "</body> </html>";
  }

function abhaken($flurid,$dbn,$width,$nbrkspc)
{

$query4="SELECT * FROM flur WHERE ID=$flurid";
     $result4=mysql_db_query($dbn,$query4);
     $r4=mysql_fetch_array($result4);

 echo "<tr><td>&nbsp;</td><td>";
 if ($r4[db_datum]>'0000-00-00') echo "<img src=\"images/buttons/haken.jpg\"  border=\"0\" width=\"$width\">";
  else echo "<img src=\"images/buttons/kreuz.jpg\"  border=\"0\" width=\"$width\">";
  if ($nbrkspc=='1') echo "<td>&nbsp;</td>";
  echo "<td>";
if (($r4[strha_alk]=='1') AND ($r4[strha_alb]=='1') OR ($r4[geb]=='0')) echo "<img src=\"images/buttons/haken.jpg\"  border=\"0\" width=\"$width\">";
  else echo "<img src=\"images/buttons/kreuz.jpg\"  border=\"0\" width=\"$width\">";
  if ($nbrkspc=='1') echo "<td>&nbsp;</td>";
  echo "<td>";
   if (($r4[altgeb_db_dat]>'0000-00-00') AND ($r4[geb_abschl_dat]>'0000-00-00') OR ($r4[geb]=='0'))echo "<img src=\"images/buttons/haken.jpg\"  border=\"0\" width=\"$width\">";
  else echo "<img src=\"images/buttons/kreuz.jpg\"  border=\"0\" width=\"$width\">";
  if ($nbrkspc=='1') echo "<td>&nbsp;</td>";
  echo "<td>";
   if ((($r4[alkis_feld_stat]=='1') AND ($r4[alkis_felddb_dat]!='0000-00-00')) AND ($r4[alkis_albalk_stat]=='1'))echo "<img src=\"images/buttons/haken.jpg\"  border=\"0\" width=\"$width\">";
  else echo "<img src=\"images/buttons/kreuz.jpg\"  border=\"0\" width=\"$width\">";
  if ($nbrkspc=='1') echo "<td>&nbsp;</td>";
  echo "<td>";
   if (($r4[bos_exists]=='1') AND ($r4[bos_alk]=='1')) echo "<img src=\"images/buttons/haken.jpg\"  border=\"0\" width=\"$width\">";
  else echo "<img src=\"images/buttons/kreuz.jpg\"  border=\"0\" width=\"$width\">";
  if ($nbrkspc=='1') echo "<td>&nbsp;</td>";
  echo "<td>";
 if (($r4[all_riss_dat]>'0000-00-00') AND ($r4[gesc_riss_dat]>'0000-00-00') AND ($r4[gesc_riss_kvz]=='1') AND ($r4[all_riss_kvz]=='1') AND ($r4[anlagen_dat]>'0000-00-00') AND ($r4[georef_dat]>'0000-00-00') ) echo "<img src=\"images/buttons/haken.jpg\"  border=\"0\" width=\"$width\">";
  else echo "<img src=\"images/buttons/kreuz.jpg\"  border=\"0\" width=\"$width\">";
  if ($nbrkspc=='1') echo "<td>&nbsp;</td>";
  echo "<td>";
 }



 function flur_kopf($flurid,$dbname)
 {
 $query="SELECT * FROM flur WHERE ID=$flurid";
 $result=mysql_db_query($dbname,$query);
 $r=mysql_fetch_array($result);
 echo "<div align=\"center\"><table border=\"0\">
<tr  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\" bgcolor=\"#a0a0a0\">
 <td width=\"300\">Gemarkung </td>
 <td> Gemarkungsnummer</td>
 <td > Flur</td>
 <td> Vertrag</td>
 </tr>
<tr style=\"font-family:Arial; font-size: 12pt; font-weight: bold\">
<td>";
$query4="SELECT * FROM gemarkung WHERE gemark_id=$r[gemkg_id]";
     $result4=mysql_db_query($dbname,$query4);
     $r4=mysql_fetch_array($result4);
     echo"$r4[gemarkung]
</td>
<td>$r[gemkg_id]</td>
<td style=\"font-family:Arial; font-size: 24pt; font-weight: bold\">$r[flur_id]</td>";
if ($r[vertrag_id]=='0')
  {
   echo "<td>$r[vertrag]</td></tr>";
  }
  else
  {
   $vquery="SELECT * FROM vertrag WHERE vertrag_id=$r[vertrag_id]";
   $vresult=mysql_db_query($dbname,$vquery);
   $rv=mysql_fetch_array($vresult);
   echo "<td>$rv[name]<br>";
   $v2query="SELECT * FROM vermst WHERE vermst_id=$rv[vermst_id]";
   $v2result=mysql_db_query($dbname,$v2query);
   $rv2=mysql_fetch_array($v2result);
   echo"$rv2[vermst]</td></tr>";
  }
if ($r[bov]>='1')
  {
  $bovquery="SELECT * FROM bov WHERE bov_id=$r[bov]";
  $bovresult=mysql_db_query($dbname,$bovquery);
  $bovr=mysql_fetch_array($bovresult);
  echo "<tr><td style=\"font-family:Arial; font-size: 8pt; font-weight: bold\" colspan=\"4\">BOV: $bovr[Name]&nbsp;";
  if ($r[bov_teilw]=='1') echo "(teilweise)";
  echo ",&nbsp;Ausf&uuml;hrende Stelle: $bovr[ausf_vermst]";
  if ($bovr[busy]=='0') echo ", Verfahren ist abgeschlossen";
  if ($bovr[busy]=='1') echo ", Verfahren l&auml;uft noch";
  echo "</td></tr>";
  }
if ($r[geb]=='0') echo "<tr><td style=\"font-family:Arial; font-size: 8pt; font-weight: bold\">kein Geb&auml;udebestand</td></tr>";

echo "</table><br>";
}

function head_baustellen()
 {
  echo " <html>
  <head>
  <meta http-equiv=\"pragma\" content=\"nocache\">
  <title>
    Baustellen
  </title>
  </head>

  <body bgcolor=\"#000000\" text=\"#FCFDBF\">
<h3 align=\"center\" style=\"font-family:Arial; font-size: 24pt; font-weight: bold\">Baustellen</h3>";
}


function write_log($fn,$logcontent)
{
  $filename="log/".$fn;
  $logcontent=$logcontent."\n";
  if (file_exists($filename))
   {
     $logfile=fopen($filename,"a");
   }
   else
   {
     $logfile=fopen($filename,"w");
   }
   fputs($logfile,$logcontent);
   fclose($logfile);
}

function navi_flur($what,$id)
{
   echo" <font face=\"Arial\" size=\"-1\"><table border=\"0\">
   <tr>
   <td>";
   if ($what == 'fstn')
   { echo "<img src=\"images/buttons/flst_red.gif\"  border=\"0\" width=\"100\">";}
   else
   { echo "<a href=\"flur_show_fstn.php?id=$id\"><img src=\"images/buttons/flst_gray.gif\"  border=\"0\" width=\"100\"></a></td>";}
   if ($what == 'alk_grund')
   {
     echo "<td><img src=\"images/buttons/alk_grund_red.gif\"  border=\"0\" width=\"100\"></td>";
   }
   else
   {
     echo "<td><a href=\"flur_edit_alkgrund.php?id=$id\"><img src=\"images/buttons/alk_grund_gray.gif\"  border=\"0\" width=\"100\"></a></td>";
   }
   if ($what == 'alk_strha')
   {
     echo "<td><img src=\"images/buttons/alk_strha_red.gif\"  border=\"0\" width=\"100\"></td>";
   }
   else
   {
     echo "<td><a href=\"flur_edit_strha.php?id=$id\"><img src=\"images/buttons/alk_strha_gray.gif\"  border=\"0\" width=\"100\"></a></td>";
   }
   if ($what == 'alk_geb')
   {
     echo "<td><img src=\"images/buttons/alk_geb_red.gif\"  border=\"0\" width=\"100\"></td>";
   }
   else
   {
     echo "<td><a href=\"flur_edit_geb.php?id=$id\"><img src=\"images/buttons/alk_geb_gray.gif\"  border=\"0\" width=\"100\"></a></td>";
   }
   if ($what == 'alkis')
   {
     echo "<td><img src=\"images/buttons/alkis_red.gif\"  border=\"0\" width=\"100\"></td>";
   }
   else
   {
     echo "<td><a href=\"flur_edit_alkis.php?id=$id\"><img src=\"images/buttons/alkis_gray.gif\"  border=\"0\" width=\"100\"></a></td>";
   }
   if ($what == 'bos')
   {
     echo "<td><img src=\"images/buttons/bos_red.gif\"  border=\"0\" width=\"100\"></td>";
   }
   else
   {
     echo "<td><a href=\"flur_edit_bos.php?id=$id\"><img src=\"images/buttons/bos_gray.gif\"  border=\"0\" width=\"100\"></a></td>";
   }
   if ($what == 'kvwmap')
   {
     echo "<td><img src=\"images/buttons/kvwmap_red.gif\"  border=\"0\" width=\"100\"></td>";
   }
   else
   {
     echo "<td><a href=\"flur_edit_kvwmap.php?id=$id\"><img src=\"images/buttons/kvwmap_gray.gif\"  border=\"0\" width=\"100\"></a></td>";
   }

echo "</tr></font>";
}

function navi_flur_search($what)
{
echo" <table border=\"0\"><tr>";
if ($what == 'alkgrund') echo "<td><img src=\"images/buttons/alk_grund_red.gif\"  border=\"0\" width=\"100\"></td>";
 else echo "<td><a href=\"flur_search_alkgrund.php\"><img src=\"images/buttons/alk_grund_gray.gif\"  border=\"0\" width=\"100\"></a></td>";

if ($what == 'strha') echo "<td><img src=\"images/buttons/alk_strha_red.gif\"  border=\"0\" width=\"100\"></td>";
 else echo "<td><a href=\"flur_search_strha.php\"><img src=\"images/buttons/alk_strha_gray.gif\"  border=\"0\" width=\"100\"></a></td>";

if ($what == 'geb') echo "<td><img src=\"images/buttons/alk_geb_red.gif\"  border=\"0\" width=\"100\"></td>";
 else echo "<td><a href=\"flur_search_geb.php\"><img src=\"images/buttons/alk_geb_gray.gif\"  border=\"0\" width=\"100\"></a></td>";

if ($what == 'alkis') echo "<td><img src=\"images/buttons/alkis_red.gif\"  border=\"0\" width=\"100\"></td>";
 else echo "<td><a href=\"flur_search_alkis.php\"><img src=\"images/buttons/alkis_gray.gif\"  border=\"0\" width=\"100\"></a></td>";

if ($what == 'bos') echo "<td><img src=\"images/buttons/bos_red.gif\"  border=\"0\" width=\"100\"></td>";
 else echo "<td><a href=\"flur_search_bos.php\"><img src=\"images/buttons/bos_gray.gif\"  border=\"0\" width=\"100\"></a></td>";

if ($what == 'kvwmap') echo "<td><img src=\"images/buttons/kvwmap_red.gif\"  border=\"0\" width=\"100\"></td>";
 else echo "<td><a href=\"flur_search_kvwmap.php\"><img src=\"images/buttons/kvwmap_gray.gif\"  border=\"0\" width=\"100\"></a></td>";

echo "</tr></table>";

}

function absolute($wert)
 {
  $pos1=strpos($wert,".");
  if ($pos1 == false)
   {
    $abswert=$wert;
   }
   else
   {
    $wertarry=explode(".",$wert);
    $abswert=$wertarry[0];
   }

   return $abswert;
  }

function showarray($zk,$start,$laenge)
  {
   $anzeige=substr($zk,$start,$laenge);
   if (strlen($zk) > $laenge) $anzeige=$anzeige."...";
   return $anzeige;
  }

?>