<?php

include("connect.php");


$titel=$_POST["titel"];
$author=$_POST["author"];
$message=$_POST["message"];

$query="INSERT INTO news (author,titel,message)
VALUES
('$author','$titel','$message');";
mysql_query($query) OR DIE ("Der Eintrag konnte nicht angelegt werden...");

echo "<p align=center>";
echo "Der neue Eintrag wurde angelegt.";
echo "</b>";
?>