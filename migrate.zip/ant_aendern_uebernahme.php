<?php
include ("connect.php");
include ("function.php");

head_ant();
nav_ant();

if ((strpos($abteilung,"ueb") > -1) OR (strpos($abteilung,"adm") > -1)) $ueb =1;


$id=$_GET["id"];
$page=$_GET["page"];


$query="SELECT o.*, x.* FROM antrag as o, antrag_extra as x  WHERE o.id=$id  AND o.id=x.id";
$result=mysql_db_query($dbname,$query);
$r=mysql_fetch_array($result);
if($r[id]>0)
{
$aktenz=$r[number]."/".substr($r[year],2,2);
echo"<form action=\"ant_aendern_einfuegen_ueb.php\" method=\"post\" target=\"\">
<input type=hidden name=\"id\" value=\"$id\">";
echo "<input type=hidden name=\"page\" value=\"$page\">";

nav_aendern($id,$dbname,$page);

if ($ueb != 1) echo "<div style=\"font-family:Arial; font-size: 10pt; font-weight: bold\">
 Der Nutzer $username ist nicht berechtigt �bernahmedaten zu �ndern!</div>";
echo "<table border=\"1\">
<tr bgcolor=\"#EFA036\">
<td colspan=\"4\" style=\"font-family:Arial; font-size: 14pt; font-weight: bold\"> &Uuml;bernahme&nbsp;&nbsp;$aktenz&nbsp;</td></tr>
<tr bgcolor=\"#EFA036\">
<td colspan=\"4\" style=\"font-family:Arial; font-size: 10pt; font-weight: bold\">
<table style=\"font-family:Arial; font-size: 10pt; font-weight: bold\">
<tr>";
$query10="SELECT * FROM vermst WHERE vermst_id=$r[vermst_id]";
     $result10=mysql_db_query($dbname,$query10);
     $r10=mysql_fetch_array($result10);
     echo"<td>$r10[vermst],&nbsp;</td>";
$query12="SELECT * FROM vermart WHERE vermart_id=$r[vermart_id]";
     $result12=mysql_db_query($dbname,$query12);
     $r12=mysql_fetch_array($result12);
     echo"<td>$r12[vermart],&nbsp;</td>";
$query11="SELECT * FROM gemarkung WHERE gemark_id=$r[gemark_id_1]";
     $result11=mysql_db_query($dbname,$query11);
     $r11=mysql_fetch_array($result11);
     echo"<td>$r11[gemarkung]&nbsp;($r[gemark_id_1])";
 if ($r[flur_1]!="") echo ",&nbsp;Flur: $r[flur_1]";
 if ($r[flst_1alt]!="") echo ",&nbsp;Flurst.:",showarray($r[flst_1alt],0,10),"</td></tr>";

if ($r[gemark_id_2] != 0)
  {
 echo "<tr><td>&nbsp;</td><td>&nbsp;</td>";
$query11="SELECT * FROM gemarkung WHERE gemark_id=$r[gemark_id_2]";
     $result11=mysql_db_query($dbname,$query11);
     $r11=mysql_fetch_array($result11);
echo "<td>$r11[gemarkung]&nbsp;($r[gemark_id_2])";
 if ($r[flur_2]!="") echo ",&nbsp;Flur: $r[flur_2]";
 if ($r[flst_2alt]!="") echo ",&nbsp;Flurst.:",showarray($r[flst_2alt],0,10),"</td></tr>";
 }

if ($r[gemark_id_3] != 0)
  {
 echo "<tr><td>&nbsp;</td><td>&nbsp;</td>";
$query11="SELECT * FROM gemarkung WHERE gemark_id=$r[gemark_id_3]";
     $result11=mysql_db_query($dbname,$query11);
     $r11=mysql_fetch_array($result11);
echo "<td>$r11[gemarkung]&nbsp;($r[gemark_id_3])";
 if ($r[flur_3]!="") echo ",&nbsp;Flur: $r[flur_3]";
 if ($r[flst_3alt]!="") echo ",&nbsp;Flurst.:",showarray($r[flst_3alt],0,10),"</td></tr>";
 }

 echo "</table></td>
</tr>";

echo "<tr bgcolor=\"#EFA036\">
 <td>&Uuml;-Datum </td>
 <td>Mitarbeiter</td>
 <td>&Uuml;bernahme Ok?</td>
 <td>Aktenort</td>
</tr>
<tr>

 <td><input type=\"date\" name=\"ueb_datum\" value=\"$r[ueb_datum]\" size=\"10\" maxlength=\"10\"><a href=\"set_date.php?id=$r[id]&script=ant_aendern_uebernahme.php&table=antrag&column=ueb_datum&page=$page\"><img src=\"images/buttons/b_calendar.png\" alt=\"\" border=\"0\"></a> </td>
 <td><select name=\"ueb_mit_id\">";

 $query2="SELECT * FROM mitarbeiter WHERE abteilung LIKE '%ueb%'";
 $result2=mysql_db_query($dbname,$query2);

 while($r2=mysql_fetch_array($result2))
   {
   echo "<option";
   if($r2[mitarb_id] == $r[ueb_mit_id])
   {
   echo " selected";
   }
   echo " value=\"$r2[mitarb_id]\">$r2[name]</option>\n";
   }
   echo "
      </select>
   </td>
      <td><select name=\"ueb_ja_nein\">
   <option";
   if($r[ueb_ja_nein]==0)
    {
    echo " selected";
    }
    echo " value=\"0\">nein</option>
   <option";
   if($r[ueb_ja_nein]==1)
    {
    echo " selected";
    }
    echo " value=\"1\">ja</option>
   </select></td>
   <td><select name=\"aktort_id\">";

 $query3="SELECT * FROM aktort ORDER BY aktort_id";
 $result3=mysql_db_query($dbname,$query3);

 while($r3=mysql_fetch_array($result3))
   {
   echo "<option";
   if($r3[aktort_id] == $r[aktort_id])
   {
   echo " selected";
   }
   echo " value=\"$r3[aktort_id]\">$r3[aktort]</option>\n";
   }
   echo "
      </select>
   </td>
</tr>
<tr>
 <td bgcolor=\"#EFA036\" colspan=\"3\">&Auml;nderungsnachweis</td>
 <td align=\"left\" style=\"font-family:Arial; font-size: 12pt; font-weight: bold\" rowspan=\"7\">";

if ($r[gemark_id_1] > 0)
 {
 if (($r[riss_1]=='0') AND ($ueb=='1') AND ($r[me_datum] > "2007-07")) echo "$r[gemark_id_1]&nbsp;Rissnummer: $r[riss_1]&nbsp;<a href=\"ant_riss.php?id=$id&gemark_id=$r[gemark_id_1]&n=1\"><img src=\"images/buttons/s_warn.png\"  border=\"0\" alt=\"Rissnummer automatisch vergeben\"></a>";
 else echo "$r[gemark_id_1]&nbsp;Rissnummer: $r[riss_1]";
echo "<br>";
 }
if ($r[gemark_id_2] > 0)
 {
 if (($r[riss_2]==0) AND ($ueb==1) AND ($r[me_datum] > "2007-07")) echo "$r[gemark_id_2]&nbsp;Rissnummer: $r[riss_2]&nbsp;<a href=\"ant_riss.php?id=$id&gemark_id=$r[gemark_id_2]&n=2\"><img src=\"images/buttons/s_warn.png\"  border=\"0\" alt=\"Rissnummer automatisch vergeben\"></a>";
 else echo "$r[gemark_id_2]&nbsp;Rissnummer: $r[riss_2]";
echo "<br>";
 }

if ($r[gemark_id_3] > 0)
 {
 if (($r[riss_3]==0) AND ($ueb==1) AND ($r[me_datum] > "2007-07")) echo "$r[gemark_id_3]&nbsp;Rissnummer: $r[riss_3]&nbsp;<a href=\"ant_riss.php?id=$id&gemark_id=$r[gemark_id_3]&n=3\"><img src=\"images/buttons/s_warn.png\"  border=\"0\" alt=\"Rissnummer automatisch vergeben\"></a>";
 else echo "$r[gemark_id_3]&nbsp;Rissnummer: $r[riss_3]";
 }

echo "</td></tr>
<tr>
 <td colspan=\"3\"><input type=\"Text\" name=\"ueb_aen\" value=\"$r[ueb_aen]\" size=\"50\" maxlength=\"50\"> </td>
 </tr>
 <tr bgcolor=\"#EFA036\">
 <td colspan=\"3\">ALK </td>
 </tr>
 <tr bgcolor=\"#EFA036\">
 <td >ALK-Datum </td>
 <td>Mitarbeiter</td>
 <td>ALK OK?</td>
</tr>
<tr>
 <td><input type=\"date\" name=\"alk_datum\" value=\"$r[alk_datum]\" size=\"10\" maxlength=\"10\"><a href=\"set_date.php?id=$r[id]&script=ant_aendern_uebernahme.php&table=antrag&column=alk_datum&page=$page\"><img src=\"images/buttons/b_calendar.png\" alt=\"\" border=\"0\"></a> </td>
 <td>
 <select name=\"alk_mit_id\">";

 $query4="SELECT * FROM mitarbeiter WHERE abteilung LIKE '%alk%'";
 $result4=mysql_db_query($dbname,$query4);

 while($r4=mysql_fetch_array($result4))
   {
   echo "<option";
   if($r4[mitarb_id] == $r[alk_mit_id])
   {
   echo " selected";
   }
   echo " value=\"$r4[mitarb_id]\">$r4[name]</option>\n";
   }
   echo "
      </select>
 </td>

    <td><select name=\"alk_ja_nein\">
   <option";
   if($r[alk_ja_nein]==0)
    {
    echo " selected";
    }
    echo " value=\"0\">nein</option>
   <option";
   if($r[alk_ja_nein]==1)
    {
    echo " selected";
    }
    echo " value=\"1\">ja</option>
   <option";
   if($r[alk_ja_nein]==2)
    {
    echo " selected";
    }
    echo " value=\"2\">keine ALK</option>

   </select></td>
</tr>
 <tr bgcolor=\"#EFA036\">
 <td colspan=\"3\">ALB </td>
 </tr>
 <tr bgcolor=\"#EFA036\">
 <td >ALB-Datum </td>
 <td>Mitarbeiter</td>
 <td>ALB OK?</td>
</tr>
<tr>
 <td><input type=\"date\" name=\"alb_datum\" value=\"$r[alb_datum]\" size=\"10\" maxlength=\"10\"><a href=\"set_date.php?id=$r[id]&script=ant_aendern_uebernahme.php&table=antrag&column=alb_datum&page=$page\"><img src=\"images/buttons/b_calendar.png\" alt=\"\" border=\"0\"></a> </td>
 <td>
 <select name=\"alb_mit_id\">";

 $query6="SELECT * FROM mitarbeiter WHERE abteilung LIKE '%alb%'";
 $result6=mysql_db_query($dbname,$query6);

 while($r6=mysql_fetch_array($result6))
   {
   echo "<option";
   if($r6[mitarb_id] == $r[alb_mit_id])
   {
   echo " selected";
   }
   echo " value=\"$r6[mitarb_id]\">$r6[name]</option>\n";
   }
   echo "
      </select>
 </td>

    <td><select name=\"alb_ja_nein\">
   <option";
   if($r[alb_ja_nein]==0)
    {
    echo " selected";
    }
    echo " value=\"0\">nein</option>
   <option";
   if($r[alb_ja_nein]==1)
    {
    echo " selected";
    }
    echo " value=\"1\">ja</option>
   <option";
   if($r[alb_ja_nein]==2)
    {
    echo " selected";
    }
    echo " value=\"2\">kein ALB</option>
   </select></td>
</tr>";

if ($ueb ==1)
 {
  echo " <tr>
 <td colspan=\"5\" bgcolor=\"#EFA036\"> <input type=\"Submit\" name=\"\" value=\"&Auml;nderungen eintragen\">&nbsp;&nbsp;<input type=\"reset\">&nbsp;
 </td>";
  }
  else
  {
   echo "<tr> <td colspan=\"5\" bgcolor=\"#EFA036\"> &nbsp; </td>";
  }
echo "</tr>
</table>";
}
else
{
echo "<h3>Die Antragsnummer --> ",$id," <-- ist (noch) nicht vergeben..</h3>";
}
echo "</form>";


nav_ant();
bottom();
?>