<html>
<head>
<title>Neues</title>
<meta name="author" content="Thurm">
<meta name="generator" content="Ulli Meybohms HTML EDITOR">
</head>
<body text="#FFFFFF" bgcolor="#200776" link="#FFFFFF" alink="#E9FA14" vlink="#FF0000">
<?php
include ("connect.php");
?>
<input type=button value="News eintragen" onClick='window.open("news_edit.php")'> <br>
<br>

<?php
$query="SELECT * FROM news ORDER BY date desc;";
$result=mysql_db_query($dbname,$query);

while($r=mysql_fetch_array($result))
  {
  echo"
  <hr>
  <table border=\"0\">
  <tr>
  <td>Datum:$r[date]</td>
  </tr>
  <tr>
  <td>Autor: $r[author]</td>
  </tr>
  <tr>
  <td><h2>$r[titel]</h2></td>
  </tr>
  <tr>
  <td><textarea name=\"\" cols=\"65\" rows=\"10\">$r[message]</textarea></td>
  </tr>
</table>
<br>";
  }
?>
</body>
</html>