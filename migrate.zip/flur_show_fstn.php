<?php
include ("connect.php");
include ("function.php");

head_flur();
nav_flur("alkgrund");

$id=$_GET["id"];
$nachfolger=$id+1;
$vorgaenger=$id-1;
$query="SELECT * FROM flur WHERE ID=$id";
$result=mysql_db_query($dbname,$query);
$r=mysql_fetch_array($result);


flur_kopf($id,$dbname);
navi_flur("fstn",$id);
abhaken($r[ID],$dbname,"80",0);
echo"</table><br>";

     $fstnquery="SELECT * FROM fstn WHERE gemarkung=$r[gemkg_id] AND flur=$r[flur_id] ORDER BY zaehler";
     $fstnresult=mysql_db_query($dbname,$fstnquery);
     $fstn=0;
     echo "<table border=\"0\"><tr>";
     while($fstnr=mysql_fetch_array($fstnresult))
      {
      echo "<td width=\"50\" style=\"font-family:Arial; font-size: 12pt; font-weight: bold\"><a href=\"flur_edit_fstn.php?gemarkung=$r[gemkg_id]&flur=$r[flur_id]&zaehler=$fstnr[zaehler]&id=$id\">$fstnr[zaehler]&nbsp;<small>$fstnr[nenner]</small></a><td>";
      $fstn=$fstn+1;
      $quot=$fstn%10;
      if($quot ==0) echo "</tr><tr>";
      }
echo "</tr></table><br><br>";
     if ($fstn==0)
   {
    echo "Noch nichts erfasst ...<br>";
   }
echo"<br><a href=\"flur_eintrag_fstn.php?gemarkung=$r[gemkg_id]&flur=$r[flur_id]&id=$id\">[Neuen Z�hler erfassen]</a><br><br>";
echo "<a  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\" href=\"flur_show_fstn.php?id=$vorgaenger\"><img src=\"images/buttons/pfeil_links.png\" alt=\"\" border=\"0\" width=\"120\"></a>&nbsp;&nbsp;
 <a  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\" href=\"flur_show_fstn.php?id=$nachfolger\"><img src=\"images/buttons/pfeil_rechts.png\" alt=\"\" border=\"0\" width=\"120\"></a></a></a></a></div><br> <br> ";


nav_flur("alkgrund");
bottom();
?>