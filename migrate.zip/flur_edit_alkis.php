<?php
include ("connect.php");
include ("function.php");

head_flur();
nav_flur("alkis");

$id=$_GET["id"];
$nachfolger=$id+1;
$vorgaenger=$id-1;
$query="SELECT * FROM flur WHERE ID=$id";
$result=mysql_db_query($dbname,$query);
$r=mysql_fetch_array($result);

flur_kopf($id,$dbname);
navi_flur("alkis",$id);
abhaken($r[ID],$dbname,"80",0);

 echo"</table>
<form action=\"flur_ins_alkis.php\" method=\"post\" target=\"\">
<input type=hidden name=\"id\" value=\"$id\">";

echo "<br><table>
<tr valign=\"top\"><td>
<table border=\"1\">
<tr style=\"font-family:Arial; font-size: 12pt; font-weight: bold\">
<td bgcolor=\"#ECD513\" colspan=\"2\">ALKIS-Vormigration<br>Feldvergleich (Geb&auml;ude)</td>
</tr>";
if ($r[geb]=='0')
 {
 echo "<tr><td align=\"center\"><img src=\"images/no_house.jpg\"  border=\"0\" width=\"90\"></td></tr>";
 }
 else
 {
echo "<tr style=\"font-family:Arial; font-size: 10pt; font-weight: bold\">
<td bgcolor=\"#ECD513\">abgeschlossen am:</td>
<td><input  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\" type=\"date\" name=\"alkis_feld_dat\" value=\"$r[alkis_feld_dat]\" size=\"10\" ></td>
</tr>
<tr style=\"font-family:Arial; font-size: 10pt; font-weight: bold\">
<td bgcolor=\"#ECD513\">Mitarbeiter:</td>
<td>
 <select  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\" name=\"alkis_feld_mitid\">";

 $query5="SELECT * FROM mitarbeiter WHERE abteilung LIKE '%feld%'";
 $result5=mysql_db_query($dbname,$query5);

 while($r5=mysql_fetch_array($result5))
   {
   echo "<option style=\"font-family:Arial; font-size: 10pt; font-weight: bold\"";
   if($r5[mitarb_id] == $r[alkis_feld_mitid])
   {
   echo " selected";
   }
   echo " value=\"$r5[mitarb_id]\">$r5[name]</option>\n";
   }
   echo "
      </select>
 </td>
</tr>
<tr style=\"font-family:Arial; font-size: 10pt; font-weight: bold\">
<td bgcolor=\"#ECD513\">Status</td>
<td><select  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\" name=\"alkis_feld_stat\">
   <option style=\"font-family:Arial; font-size: 10pt; font-weight: bold\"";
   if($r[alkis_feld_stat]==0)
    {
    echo " selected";
    }
    echo " value=\"0\">keine Aktion</option>
   <option style=\"font-family:Arial; font-size: 10pt; font-weight: bold\"";
   if($r[alkis_feld_stat]==1)
    {
    echo " selected";
    }
    echo " value=\"1\">abgeschlossen</option>
    </select></td>
</tr>
<tr style=\"font-family:Arial; font-size: 10pt; font-weight: bold\">
<td bgcolor=\"#ECD513\">in DB eingearbeitet am:</td>
<td><input  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\" type=\"date\" name=\"alkis_felddb_dat\" value=\"$r[alkis_felddb_dat]\" size=\"10\" ></td>
</tr>
<tr style=\"font-family:Arial; font-size: 10pt; font-weight: bold\">
<td bgcolor=\"#ECD513\">Mitarbeiter:</td>
<td>
 <select  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\" name=\"alkis_felddb_mitid\">";

 $query10="SELECT * FROM mitarbeiter WHERE abteilung LIKE '%vbk%'";
 $result10=mysql_db_query($dbname,$query10);

 while($r10=mysql_fetch_array($result10))
   {
   echo "<option style=\"font-family:Arial; font-size: 10pt; font-weight: bold\"";
   if($r10[mitarb_id] == $r[alkis_felddb_mitid])
   {
   echo " selected";
   }
   echo " value=\"$r10[mitarb_id]\">$r10[name]</option>\n";
   }
   echo "
      </select>
 </td>
 </tr>";
}
echo "</table>
</td>
<td>&nbsp;&nbsp;</td>
<td>
<table border=\"1\">
<tr style=\"font-family:Arial; font-size: 12pt; font-weight: bold\">
<td bgcolor=\"#ECD513\" colspan=\"2\">ALKIS-Vormigration<br>Abgleich ALB-ALK</td>
</tr>
<tr style=\"font-family:Arial; font-size: 10pt; font-weight: bold\">
<td width=\"300\" bgcolor=\"#ECD513\">abgeschlossen am:</td>
<td><input  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\" type=\"date\" name=\"alkis_albalk_dat\" value=\"$r[alkis_albalk_dat]\" size=\"10\" ></td>
</tr>
<tr style=\"font-family:Arial; font-size: 10pt; font-weight: bold\">
<td width=\"300\" bgcolor=\"#ECD513\">Mitarbeiter:</td>
<td>
 <select  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\" name=\"alkis_albalk_mitid\">";

 $query5="SELECT * FROM mitarbeiter WHERE abteilung LIKE '%vbk%'";
 $result5=mysql_db_query($dbname,$query5);

 while($r5=mysql_fetch_array($result5))
   {
   echo "<option style=\"font-family:Arial; font-size: 10pt; font-weight: bold\"";
   if($r5[mitarb_id] == $r[alkis_albalk_mitid])
   {
   echo " selected";
   }
   echo " value=\"$r5[mitarb_id]\">$r5[name]</option>\n";
   }
   echo "
      </select>
 </td>
</tr>
<tr style=\"font-family:Arial; font-size: 10pt; font-weight: bold\">
<td bgcolor=\"#ECD513\">Status</td>
<td><select  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\" name=\"alkis_albalk_stat\">
   <option style=\"font-family:Arial; font-size: 10pt; font-weight: bold\"";
   if($r[alkis_albalk_stat]==0)
    {
    echo " selected";
    }
    echo " value=\"0\">keine Aktion</option>
   <option style=\"font-family:Arial; font-size: 10pt; font-weight: bold\"";
   if($r[alkis_albalk_stat]==1)
    {
    echo " selected";
    }
    echo " value=\"1\">abgeschlossen</option>
    <option style=\"font-family:Arial; font-size: 10pt; font-weight: bold\"";
   if($r[alkis_albalk_stat]==2)
    {
    echo " selected";
    }
    echo " value=\"2\">&Uuml;berhaken entfernen</option>
    </select></td>
</tr>

</table>
</td></tr>
</table>

<br>
<input  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\" type=\"Submit\" value=\"&Auml;nderungen eintragen\">&nbsp;<input  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\" type=\"reset\">";
echo "</form>";
echo "<br><br>";
echo "<a  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\" href=\"flur_edit_alkis.php?id=$vorgaenger\"><img src=\"images/buttons/pfeil_links.png\" alt=\"\" border=\"0\" width=\"120\"</a>&nbsp;&nbsp;
 <a  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\" href=\"flur_edit_alkis.php?id=$nachfolger\"><img src=\"images/buttons/pfeil_rechts.png\" alt=\"\" border=\"0\" width=\"120\"</a></a></a></a></div><br> <br> ";


nav_flur("alkis");
bottom();
?>