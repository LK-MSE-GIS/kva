
<?php

include("connect.php");
include("function.php");

$gemark_id=$_GET["gemark_id"];
$id=$_GET["id"];
$n=$_GET["n"];

echo "<head>
<meta http-equiv=\"refresh\" content=\"0; URL=ant_aendern_uebernahme.php?id=$id\">
</head>";

$query="SELECT * from riss_nummer where gemark_id = '$gemark_id';";
$result=mysql_db_query($dbname,$query);
$r=mysql_fetch_array($result);
$rissnummer=$r[last_riss]+1;

$query="update riss_nummer set last_riss=$rissnummer where gemark_id='$gemark_id';";
mysql_query($query) OR DIE ("Der Eintrag konnte nicht angelegt werden...");

 if ($n==1) $query="update antrag set riss_1=$rissnummer where id='$id';";
 if ($n==2) $query="update antrag set riss_2=$rissnummer where id='$id';";
 if ($n==3) $query="update antrag set riss_3=$rissnummer where id='$id';";

mysql_query($query) OR DIE ("Der Eintrag konnte nicht angelegt werden...");


bottom();
?>