<?php
include ("connect.php");
include ("function.php");

head_flur();
nav_flur("geb");

$id=$_GET["id"];
$nachfolger=$id+1;
$vorgaenger=$id-1;
$query="SELECT * FROM flur WHERE ID=$id";
$result=mysql_db_query($dbname,$query);
$r=mysql_fetch_array($result);

flur_kopf($id,$dbname);
navi_flur("alk_geb",$id);
abhaken($r[ID],$dbname,"80",0);

 echo"</table>";

 if ($r[geb]=='1')
{
 echo"
<form action=\"flur_ins_geb.php\" method=\"post\" target=\"\">
<input type=hidden name=\"id\" value=\"$id\">";

echo "<br><table>";


echo "<tr>
<td valign=\"top\">
<table border=\"0\">
<tr style=\"font-family:Arial; font-size: 12pt; font-weight: bold\" >
<td bgcolor=\"#949091\" colspan=\"2\" >ALK - Altgeb&auml;udeerfassung</td>
</tr>";

if (($r[bov]=='0') OR (($r[bov]>'0') AND ($r[bov_teilw]=='1')))
{

echo "<tr style=\"font-family:Arial; font-size: 10pt; font-weight: bold\">
<td bgcolor=\"#949091\">Status</td>
<td><select  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\" name=\"altgeb_status\">
   <option style=\"font-family:Arial; font-size: 10pt; font-weight: bold\"";
   if($r[altgeb_status]==0)
    {
    echo " selected";
    }
    echo " value=\"0\">keine Aktion</option>
   <option style=\"font-family:Arial; font-size: 10pt; font-weight: bold\"";
   if($r[altgeb_status]==1)
    {
    echo " selected";
    }
    echo " value=\"1\">abgeschlossen</option>
    <option style=\"font-family:Arial; font-size: 10pt; font-weight: bold\"";
    if($r[altgeb_status]==2)
    {
    echo " selected";
    }
    echo " value=\"2\">Restmessung KVA</option>
    </select></td>
</tr>
<tr style=\"font-family:Arial; font-size: 10pt; font-weight: bold\">
<td bgcolor=\"#949091\">Art der Erfassung:</td>
<td><select  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\" name=\"altgeb_kartart\">
   <option style=\"font-family:Arial; font-size: 10pt; font-weight: bold\"";
   if($r[altgeb_kartart]==0)
    {
    echo " selected";
    }
    echo " value=\"0\"></option>
    <option style=\"font-family:Arial; font-size: 10pt; font-weight: bold\"";
   if($r[altgeb_kartart]==1)
    {
    echo " selected";
    }
    echo " value=\"1\">digitalisiert</option>
   <option style=\"font-family:Arial; font-size: 10pt; font-weight: bold\"";
   if($r[altgeb_kartart]==2)
    {
    echo " selected";
    }
    echo " value=\"2\">gemessen</option>
    <option style=\"font-family:Arial; font-size: 10pt; font-weight: bold\"";
   if($r[altgeb_kartart]==3)
    {
    echo " selected";
    }
    echo " value=\"3\">Luftbilduaswertung</option>
    </select></td>

</tr>

<tr style=\"font-family:Arial; font-size: 10pt; font-weight: bold\">
<td bgcolor=\"#949091\">Vermessungsstelle:</td>
<td>
 <select  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\" name=\"altgeb_vermst\">";

 $query6="SELECT * FROM vermst WHERE wvp = '1'";
 $result6=mysql_db_query($dbname,$query6);

 while($r6=mysql_fetch_array($result6))
   {
   echo "<option style=\"font-family:Arial; font-size: 10pt; font-weight: bold\"";
   if($r6[vermst_id] == $r[altgeb_vermst])
   {
   echo " selected";
   }
   echo " value=\"$r6[vermst_id]\">$r6[vermst]</option>\n";
   }
   echo "
      </select>
 </td>
</tr>
<tr>
<td colspan=\"2\"><hr></td>
</tr>
<tr style=\"font-family:Arial; font-size: 10pt; font-weight: bold\">
<td bgcolor=\"#949091\">in DB eingearbeitet am:</td>
<td><input  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\" type=\"date\" name=\"altgeb_db_dat\" value=\"$r[altgeb_db_dat]\" size=\"10\" ></td>
</tr>
<tr style=\"font-family:Arial; font-size: 10pt; font-weight: bold\">
<td bgcolor=\"#949091\">Mitarbeiter:</td>
<td>
 <select  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\" name=\"altgeb_mit_id\">";

 $query5="SELECT * FROM mitarbeiter WHERE abteilung LIKE '%alk%'";
 $result5=mysql_db_query($dbname,$query5);

 while($r5=mysql_fetch_array($result5))
   {
   echo "<option style=\"font-family:Arial; font-size: 10pt; font-weight: bold\"";
   if($r5[mitarb_id] == $r[altgeb_mit_id])
   {
   echo " selected";
   }
   echo " value=\"$r5[mitarb_id]\">$r5[name]</option>\n";
   }
   echo "
      </select>
 </td>
</tr>";

}
else
{
echo "<tr><td>erfolgt durch das BOV...</td></tr>";
}
echo "</table>
</td>
<td>&nbsp;&nbsp;</td>
<td valign=\"top\">";


echo "<table border=\"0\">
<tr style=\"font-family:Arial; font-size: 12pt; font-weight: bold\">
<td bgcolor=\"#949091\" colspan=\"2\">ALK - Geb&auml;ude ab 1992</td>
</tr>
<tr style=\"font-family:Arial; font-size: 10pt; font-weight: bold\">
<td bgcolor=\"#949091\">MS-BAU-Tabelle vom:&nbsp;</td>
<td><input  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\" type=\"date\" name=\"geb_mstab_dat\" value=\"$r[geb_mstab_dat]\" size=\"10\" ></td>
</tr>
<tr style=\"font-family:Arial; font-size: 10pt; font-weight: bold\">
<td bgcolor=\"#949091\">aufgefordert am:</td>
<td><input  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\" type=\"date\" name=\"geb_auf_dat\" value=\"$r[geb_auf_dat]\" size=\"10\" ></td>
</tr>
<tr style=\"font-family:Arial; font-size: 10pt; font-weight: bold\">
<td bgcolor=\"#949091\">abgeschlossen am:</td>
<td><input  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\" type=\"date\" name=\"geb_abschl_dat\" value=\"$r[geb_abschl_dat]\" size=\"10\" ></td>
</tr>
</table>
</td></tr></table>
</td>
</table>

<br>
<input  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\" type=\"Submit\" value=\"&Auml;nderungen eintragen\">&nbsp;<input  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\" type=\"reset\">";
echo "</form>";
}
else
{
  echo "<div align=\"center\">
        <img src=\"images/no_house.jpg\"  border=\"0\" width=\"240\">
  </div>";
}
echo "<br><br>";
echo "<a  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\" href=\"flur_edit_geb.php?id=$vorgaenger\"><img src=\"images/buttons/pfeil_links.png\" alt=\"\" border=\"0\" width=\"120\"</a>&nbsp;&nbsp;
 <a  style=\"font-family:Arial; font-size: 10pt; font-weight: bold\" href=\"flur_edit_geb.php?id=$nachfolger\"><img src=\"images/buttons/pfeil_rechts.png\" alt=\"\" border=\"0\" width=\"120\"</a></a></a></a></div><br> <br> ";


nav_flur("geb");
bottom();
?>