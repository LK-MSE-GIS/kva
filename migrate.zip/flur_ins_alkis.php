<?php

include("connect.php");
include("function.php");


head_flur();
nav_flur("alkis");


$id=$_POST["id"];
$alkis_feld_dat=$_POST["alkis_feld_dat"];
$alkis_feld_mitid=$_POST["alkis_feld_mitid"];
$alkis_feld_stat=$_POST["alkis_feld_stat"];
$alkis_felddb_mitid=$_POST["alkis_felddb_mitid"];
$alkis_felddb_dat=$_POST["alkis_felddb_dat"];
$alkis_albalk_dat=$_POST["alkis_albalk_dat"];
$alkis_albalk_mitid=$_POST["alkis_albalk_mitid"];
$alkis_albalk_stat=$_POST["alkis_albalk_stat"];

echo "<head>
<meta http-equiv=\"refresh\" content=\"0; URL=flur_edit_alkis.php?id=$id\">
</head>";

$query="UPDATE flur
           SET alkis_feld_dat='$alkis_feld_dat',
               alkis_feld_mitid='$alkis_feld_mitid',
               alkis_felddb_dat='$alkis_felddb_dat',
               alkis_felddb_mitid='$alkis_felddb_mitid',
               alkis_feld_stat='$alkis_feld_stat',
               alkis_albalk_mitid='$alkis_albalk_mitid',
               alkis_albalk_dat='$alkis_albalk_dat',
               alkis_albalk_stat='$alkis_albalk_stat'
               WHERE ID='$id';";

mysql_query($query) OR DIE ("Der Eintrag konnte nicht angelegt werden...");

$logeintrag=$year."-".$month."-".$day." ".$hour.":".$min.":".$sec." ".$username." Flur mit der ID:".$id." ALKIS-Vormighration geaendert";

write_log("fluren.log",$logeintrag);



nav_ant("alkis");
bottom();
?>